
import React, { useState, useRef, useEffect } from 'react';
import { Icons } from '../ui/Icons';
import { Message, AgentIntent, AgentStep, ReviewFinding, ActionRequest } from '../../types';
import { sendMessageToGemini, reviewCodeChanges } from '../../services/geminiService';
import { createBranch, createPullRequest } from '../../services/githubService';

interface ChatInterfaceProps {
  onCodeGenerated: (file: string, code: string, diff?: string) => void;
  onCommit: () => void;
  files: Record<string, string>;
  activeFeatureBranch: string | null;
  setActiveFeatureBranch: (branch: string | null) => void;
  unsavedChangeCount: number;
  setUnsavedChangeCount: React.Dispatch<React.SetStateAction<number>>;
  projectRepo: string; // Needed for PR creation
  projectBranch: string; // Base branch
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  onCodeGenerated, 
  onCommit, 
  files,
  activeFeatureBranch,
  setActiveFeatureBranch,
  unsavedChangeCount,
  setUnsavedChangeCount,
  projectRepo,
  projectBranch
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "I'm ready. I'll autosave your changes to a temporary session branch. When you're done, just click 'Create PR'.",
      timestamp: Date.now(),
      intent: AgentIntent.CHAT
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [visualEditsEnabled, setVisualEditsEnabled] = useState(false);
  
  // Session State
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Initialize Session Branch on first interaction if not exists
  const ensureSessionBranch = async () => {
    if (activeFeatureBranch) return activeFeatureBranch;
    
    const branchName = `webivus/session-${Date.now().toString().slice(-6)}`;
    setActiveFeatureBranch(branchName);
    setIsSessionActive(true);
    
    // Simulate creating branch on backend/git
    await createBranch("owner", "repo", branchName, "main"); // Mock params used in service
    return branchName;
  };

  const updateStepStatus = (msgId: string, stepId: string, status: 'pending' | 'active' | 'completed') => {
    setMessages(prev => prev.map(m => {
      if (m.id !== msgId || !m.steps) return m;
      return {
        ...m,
        steps: m.steps.map(s => s.id === stepId ? { ...s, status } : s)
      };
    }));
  };

  const handleSend = async (manualInput?: string) => {
    const textToSend = manualInput || inputValue;
    if (!textToSend.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: textToSend, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    if (!manualInput) setInputValue('');
    
    // We set isTyping true for state management, but won't render a separate duplicate bubble
    setIsTyping(true);

    // Ensure we have a place to save code
    const currentBranch = await ensureSessionBranch();

    const agentMsgId = (Date.now() + 1).toString();
    
    // Cycling thoughts to show activity
    const thinkingPhrases = [
       "Understanding request...",
       "Scanning project files...",
       "Reviewing code context...",
       "Architecting solution...",
       "Generating changes..."
    ];
    
    const initialSteps: AgentStep[] = [
      { id: 'think', label: thinkingPhrases[0], status: 'active', agentName: 'System' },
    ];

    setMessages(prev => [...prev, {
      id: agentMsgId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      intent: AgentIntent.DEVELOPMENT,
      steps: initialSteps
    }]);

    // Start cycling thoughts
    let phraseIdx = 0;
    const thoughtInterval = setInterval(() => {
        phraseIdx = (phraseIdx + 1) % thinkingPhrases.length;
        setMessages(prev => prev.map(m => {
            if (m.id === agentMsgId && m.steps && m.steps[0].id === 'think') {
                return {
                    ...m,
                    steps: [{ ...m.steps[0], label: thinkingPhrases[phraseIdx] }]
                };
            }
            return m;
        }));
    }, 2000);

    try {
      const response = await sendMessageToGemini(userMsg.content, files);
      clearInterval(thoughtInterval); // Stop thinking animation

      const hasChanges = response.proposedChanges && response.proposedChanges.length > 0;
      
      if (hasChanges) {
        // Plan Steps
        const dynamicSteps: AgentStep[] = [];
        if (response.plan) {
            response.plan.forEach((stepStr, idx) => {
                dynamicSteps.push({
                    id: `plan-${idx}`,
                    label: stepStr,
                    status: 'completed',
                    agentName: 'Architect'
                });
            });
        } else {
            dynamicSteps.push({ id: 'gen', label: 'Generated code changes', status: 'completed', agentName: 'Developer' });
        }

        // Review Step
        const reviewStepId = 'review-step';
        dynamicSteps.push({ id: reviewStepId, label: 'Reviewing & Autosaving...', status: 'active', agentName: 'QA Agent' });

        setMessages(prev => prev.map(m => m.id === agentMsgId ? { 
            ...m, 
            content: response.text,
            intent: response.intent,
            steps: dynamicSteps 
        } : m));

        // Review Logic
        const primaryChange = response.proposedChanges![0];
        const review = await reviewCodeChanges(primaryChange.file, primaryChange.code, files);
        
        // Apply Changes (In-memory update)
        response.proposedChanges?.forEach(change => {
          onCodeGenerated(change.file, change.code, change.diff);
        });

        // Simulate Auto-Commit to Session Branch
        // In a real app, this would POST to an API to commit to the branch
        setLastSaved(new Date());
        
        updateStepStatus(agentMsgId, reviewStepId, 'completed');

        setMessages(prev => prev.map(m => m.id === agentMsgId ? { 
          ...m, 
          reviewFindings: review.findings 
        } : m));

      } else {
        setMessages(prev => prev.map(m => m.id === agentMsgId ? { 
          ...m, 
          content: response.text,
          intent: AgentIntent.CHAT,
          steps: undefined 
        } : m));
      }

    } catch (error) {
      console.error(error);
      clearInterval(thoughtInterval);
      setMessages(prev => prev.map(m => m.id === agentMsgId ? { 
          ...m, 
          content: "Sorry, I encountered an error processing your request.",
          steps: undefined 
      } : m));
    } finally {
      setIsTyping(false);
    }
  };

  const handleCreatePR = async () => {
    if (!activeFeatureBranch) return;

    const prMsgId = Date.now().toString();
    setMessages(prev => [...prev, {
      id: prMsgId,
      role: 'assistant',
      content: 'Wrapping up session...',
      timestamp: Date.now(),
      steps: [{ id: 'pr', label: 'Creating Pull Request...', status: 'active', agentName: 'Git' }]
    }]);

    try {
        // Simulate API call
        const [owner, repo] = projectRepo.split('/');
        await createPullRequest(owner || 'user', repo || 'repo', `Feature: ${activeFeatureBranch}`, activeFeatureBranch, projectBranch);
        
        setMessages(prev => prev.map(m => m.id === prMsgId ? {
            ...m,
            content: 'Pull Request created successfully! Your session changes are ready for review.',
            steps: [{ id: 'pr', label: 'PR Created', status: 'completed', agentName: 'Git' }],
            actionRequest: { type: 'merge_pr', label: 'View Pull Request' }
        } : m));

        // Reset Session state effectively
        setLastSaved(null);
        // We keep the branch active in UI until they navigate away or start new, but logically session is "wrapped"
    } catch (e) {
        console.error("PR Failed", e);
    }
  };

  const getSeverityStyles = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      case 'low': return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      case 'success': return 'bg-green-500/10 text-green-500 border-green-500/20';
      default: return 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <Icons.AlertTriangle className="w-3.5 h-3.5" />;
      case 'medium': return <Icons.AlertCircle className="w-3.5 h-3.5" />;
      case 'low': return <Icons.Info className="w-3.5 h-3.5" />;
      case 'success': return <Icons.CheckCircle2 className="w-3.5 h-3.5" />;
      default: return <Icons.MousePointer2 className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#09090b] relative">
      <div className="h-10 px-4 border-b border-white/5 flex items-center justify-between shrink-0">
        <span className="text-xs font-medium text-zinc-500 uppercase tracking-widest">Webivus Engineering Agent</span>
        {lastSaved && (
            <div className="flex items-center gap-2 animate-in fade-in duration-500">
                <Icons.Cloud className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-[10px] text-zinc-500">Autosaved {lastSaved.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
            </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-zinc-800">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2 duration-300 w-full`}>
            <div className={`flex flex-col max-w-full w-full ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              
              {/* Dynamic Steps UI */}
              {msg.steps && msg.steps.length > 0 && (
                <div className="mb-3 w-full max-w-[85%] bg-[#0c0c0e] rounded-xl border border-white/5 overflow-hidden shadow-sm">
                  {msg.steps.map((step, idx) => (
                    <div key={idx} className="flex items-center gap-3 px-3 py-2.5 text-xs border-b border-white/5 last:border-0 transition-colors">
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                        step.status === 'completed' ? 'bg-green-500/20 text-green-500' : 
                        step.status === 'active' ? 'bg-purple-500/20 text-purple-400' : 'bg-zinc-800 text-zinc-600'
                      }`}>
                         {step.status === 'completed' ? <span className="font-bold">{idx + 1}</span> : 
                          step.status === 'active' ? <Icons.Loader2 className="w-3 h-3 animate-spin" /> : 
                          <span className="font-bold text-[10px]">{idx + 1}</span>}
                      </div>
                      <div className="flex-1 min-w-0 flex items-center justify-between">
                          <span className={`${step.status === 'active' ? 'text-white font-medium' : 'text-zinc-400'} truncate`}>
                            {step.label}
                          </span>
                          {step.agentName && step.status === 'active' && (
                              <span className="ml-2 text-[9px] uppercase tracking-wider text-purple-500/80 font-bold bg-purple-500/10 px-1.5 py-0.5 rounded">
                                  {step.agentName}
                              </span>
                          )}
                      </div>
                      {step.status === 'completed' && <Icons.Check className="w-3 h-3 text-green-500" />}
                    </div>
                  ))}
                </div>
              )}

              {msg.content && (
                <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm break-words ${
                  msg.role === 'user' 
                    ? 'bg-white text-black font-medium self-end max-w-[85%]' 
                    : 'bg-[#050505] text-zinc-300 border border-white/10 self-start max-w-[85%]'
                }`}>
                  {msg.content}
                  
                  {msg.reviewFindings && msg.reviewFindings.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-white/5 space-y-3">
                      <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">
                        <Icons.ShieldCheck className="w-3 h-3" />
                        AI Code Review Findings
                      </div>
                      {msg.reviewFindings.map((finding, idx) => (
                        <div key={idx} className={`flex gap-3 p-3 rounded-xl border animate-in fade-in zoom-in-95 duration-500 ${getSeverityStyles(finding.severity)}`}>
                          <div className="mt-0.5 shrink-0">{getSeverityIcon(finding.severity)}</div>
                          <p className="text-xs leading-relaxed font-medium">{finding.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              
              {/* Actions */}
              {msg.actionRequest && (
                  <div className="mt-3 flex gap-3 animate-in fade-in zoom-in-95">
                      <button 
                        onClick={() => { if (msg.actionRequest?.type === 'merge_pr') window.open('https://github.com', '_blank'); }}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white shadow-purple-900/20 rounded-xl text-xs font-bold flex items-center gap-2 transition-all active:scale-95 shadow-lg"
                      >
                          <Icons.ExternalLink className="w-3.5 h-3.5" />
                          {msg.actionRequest.label}
                      </button>
                  </div>
              )}
            </div>
          </div>
        ))}
        {/* Only show bottom padding, no extra loader here */}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-[#09090b] pb-28 md:pb-4 relative z-20">
        <div className={`relative bg-[#18181b] border border-white/10 rounded-2xl p-3 shadow-xl flex flex-col gap-2 transition-all ${isListening ? 'ring-2 ring-red-500/20 border-red-500/30' : 'hover:border-white/20'}`}>
          <textarea
            ref={textareaRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Describe your next feature..."
            className="w-full bg-transparent border-0 focus:ring-0 text-sm min-h-[50px] max-h-40 resize-none text-zinc-200 placeholder:text-zinc-600 px-2 py-1 leading-relaxed"
          />
          <div className="flex items-center justify-between mt-1 px-1">
             <div className="flex items-center gap-2">
                <button onClick={() => fileInputRef.current?.click()} className="p-2 text-zinc-400 hover:text-white transition-colors"><Icons.Plus className="w-5 h-5" /></button>
                <button onClick={() => setVisualEditsEnabled(!visualEditsEnabled)} className={`flex items-center gap-2 px-3 py-1.5 rounded-full border border-dashed transition-colors text-xs font-medium ${visualEditsEnabled ? 'border-purple-500/50 text-purple-400 bg-purple-500/10' : 'border-zinc-700 text-zinc-400'}`}>
                   <Icons.MousePointer2 className="w-3.5 h-3.5" /> <span>Visual edits</span>
                </button>
             </div>
             <div className="flex items-center gap-2">
                <button onClick={() => setIsListening(!isListening)} className={`p-2 rounded-full ${isListening ? 'bg-red-500 text-white animate-pulse' : 'text-zinc-400'}`}><Icons.Mic className="w-5 h-5" /></button>
                <button onClick={() => handleSend()} disabled={!inputValue.trim()} className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${inputValue.trim() ? 'bg-white text-black shadow-lg' : 'bg-zinc-800 text-zinc-600'}`}>
                   <Icons.ArrowUp className="w-5 h-5 stroke-[2.5px]" />
                </button>
             </div>
          </div>
        </div>
      </div>
      
      {/* Session Footer Actions */}
      {activeFeatureBranch && (
          <div className="absolute bottom-24 md:bottom-20 left-4 right-4 bg-[#0c0c0e]/80 backdrop-blur-md border border-white/10 p-3 rounded-2xl flex items-center justify-between shadow-2xl animate-in slide-in-from-bottom-4 duration-500">
               <div className="flex items-center gap-3">
                   <div className="flex items-center gap-1.5 px-2 py-1 bg-purple-500/10 rounded-lg border border-purple-500/20 text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                       <Icons.GitBranch className="w-3 h-3" /> {activeFeatureBranch.split('/').pop()}
                   </div>
               </div>
               <div className="flex gap-2">
                   <button onClick={handleCreatePR} className="px-3 py-1.5 bg-white text-black text-[10px] font-bold rounded-lg hover:bg-zinc-200 transition-colors flex items-center gap-2">
                      <Icons.Github className="w-3.5 h-3.5" />
                      REVIEW & CREATE PR
                   </button>
               </div>
          </div>
      )}
    </div>
  );
};

export default ChatInterface;
