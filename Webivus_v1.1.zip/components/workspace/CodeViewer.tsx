
import React, { useState, useEffect } from 'react';
import { Icons } from '../ui/Icons';
import { Highlight, themes } from 'prism-react-renderer';

interface CodeViewerProps {
  mode: 'code' | 'preview' | 'diff';
  code: string;
  originalCode: string;
  filename: string;
  files: Record<string, string>;
  onApprove: () => void;
  isPrCreating?: boolean;
}

const CodeViewer: React.FC<CodeViewerProps> = ({ mode, code, originalCode, filename, files, onApprove, isPrCreating }) => {
  const [device, setDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isLoading, setIsLoading] = useState(false);
  const [renderKey, setRenderKey] = useState(0);

  // Simulate loading state when switching to preview or when code changes
  useEffect(() => {
    if (mode === 'preview') {
      setIsLoading(true);
      const timer = setTimeout(() => setIsLoading(false), 800);
      return () => clearTimeout(timer);
    }
  }, [mode, code, filename]);

  const handleRefresh = () => {
    setIsLoading(true);
    setRenderKey(prev => prev + 1);
    setTimeout(() => setIsLoading(false), 1000);
  };

  const getLanguage = (fname: string) => {
    const lower = fname.toLowerCase();
    if (lower.endsWith('.tsx')) return 'tsx';
    if (lower.endsWith('.ts')) return 'ts';
    if (lower.endsWith('.jsx')) return 'jsx';
    if (lower.endsWith('.js')) return 'javascript';
    if (lower.endsWith('.html')) return 'html';
    if (lower.endsWith('.css')) return 'css';
    if (lower.endsWith('.json')) return 'json';
    return 'tsx';
  };

  // Helper to extract content from React files for the preview simulation
  const extractTextFromTag = (source: string | undefined, tag: string) => {
    if (!source) return null;
    // Matches <tag ...> CONTENT </tag> non-greedily
    const regex = new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)<\\/' + tag + '>', 'i');
    const match = source.match(regex);
    if (!match) return null;
    
    return match[1]
        .replace(/<br\s*\/?>/gi, ' ') // Replace breaks with space
        .replace(/\{['"]\s['"]\}/g, ' ') // Replace {' '}
        .replace(/className="[^"]*"/g, '') // Remove props in children (rare)
        .replace(/<[^>]+>/g, '') // Strip other HTML tags
        .trim();
  };
  
  // PREVIEW LOGIC: Render Landing Page
  if (mode === 'preview') {
    // Dynamic Content Extraction
    const heroFile = files['src/components/sections/Hero.tsx'];
    
    // Check if the project structure matches our demo landing page simulation
    // If not, show a generic message instead of broken UI
    if (!heroFile && !files['src/app/page.tsx']) {
         return (
             <div className="w-full h-full bg-[#050505] flex flex-col">
                 <div className="h-10 bg-[#09090b] border-b border-white/10 flex items-center px-4">
                    <div className="bg-[#000] border border-white/10 rounded-md h-7 flex items-center px-3 gap-2 text-[10px] text-zinc-400 font-mono">
                      <Icons.Lock className="w-2.5 h-2.5 text-zinc-600" />
                      <span className="text-zinc-500">https://</span>localhost:3000
                    </div>
                 </div>
                 <div className="flex-1 flex flex-col items-center justify-center text-zinc-500 p-8 text-center">
                    <Icons.AlertTriangle className="w-12 h-12 mb-4 opacity-30" />
                    <h3 className="text-lg font-medium text-zinc-300 mb-2">Preview Unavailable</h3>
                    <p className="max-w-md">The live preview simulation is designed for the demo SaaS project structure. Changes to file paths or custom imports may not render correctly in this environment.</p>
                 </div>
             </div>
         );
    }

    const heroTitle = extractTextFromTag(heroFile, 'h1') || "Automate your code.";
    const heroSubtitle = extractTextFromTag(heroFile, 'p') || "The AI-native platform that understands your entire codebase.";
    
    // Extract Badge - slightly more complex regex to find the div that contains 'v' usually
    // Fallback to static if not found
    let badgeText = "v2.0 Public Beta";
    if (heroFile) {
        const badgeMatch = heroFile.match(/<div[^>]*text-purple-400[^>]*>([\s\S]*?)<\/div>/);
        if (badgeMatch) {
            badgeText = badgeMatch[1].replace(/<[^>]+>/g, '').trim();
        }
    }

    // Check if pricing was added/injected by AI
    const hasPricing = Object.keys(files).some(k => k.toLowerCase().includes('pricing')) || 
                       files['src/app/page.tsx']?.includes('Pricing') ||
                       code.includes('Pricing');

    return (
      <div className="w-full h-full bg-[#050505] flex flex-col pb-24 md:pb-0">
        {/* Browser Chrome / Toolbar */}
        <div className="h-10 bg-[#09090b] border-b border-white/10 flex items-center justify-between px-4 shrink-0 gap-4">
          <div className="flex-1 max-w-xl mx-auto">
            <div className="bg-[#000] border border-white/10 rounded-md h-7 flex items-center px-3 gap-2 text-[10px] text-zinc-400 font-mono shadow-inner">
              <Icons.Lock className="w-2.5 h-2.5 text-green-500" />
              <span className="text-zinc-500">https://</span>
              <span className="text-white">localhost:3000</span>
            </div>
          </div>
        </div>

        {/* Viewport Area */}
        <div className="flex-1 overflow-hidden relative flex items-center justify-center bg-[#111] p-6">
           {isLoading && (
             <div className="absolute inset-0 z-50 flex items-center justify-center bg-[#050505]/50 backdrop-blur-sm">
               <div className="bg-[#18181b] border border-white/10 rounded-xl px-4 py-2 flex items-center gap-3 shadow-2xl">
                 <Icons.Loader2 className="w-4 h-4 text-purple-500 animate-spin" />
                 <span className="text-xs font-medium text-zinc-300">Compiling...</span>
               </div>
             </div>
           )}

           <div className={`bg-black transition-all duration-500 ease-in-out overflow-hidden border border-white/10 relative shadow-2xl w-full h-full rounded-lg`}>
              {/* LANDING PAGE CONTENT SIMULATION */}
              <div key={renderKey} className="w-full h-full overflow-y-auto bg-black text-white font-sans scroll-smooth">
                {/* Navbar */}
                <nav className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-md px-6 h-16 flex items-center justify-between">
                  <div className="font-bold text-lg">Acme<span className="text-purple-500">AI</span></div>
                  <div className="hidden md:flex gap-6 text-sm text-zinc-400">
                    <span className="cursor-pointer hover:text-white transition-colors">Features</span>
                    <span className="cursor-pointer hover:text-white transition-colors">Docs</span>
                    <span className="cursor-pointer hover:text-white transition-colors">Pricing</span>
                  </div>
                  <button className="px-4 py-1.5 bg-white text-black text-sm font-medium rounded-md hover:bg-zinc-200 transition-colors">Get Started</button>
                </nav>

                {/* Hero */}
                <section className="pt-24 pb-20 px-6 text-center relative overflow-hidden">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-purple-600/20 blur-[100px] rounded-full" />
                  <div className="relative z-10">
                     <span className="inline-block px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-purple-400 mb-6">
                        {badgeText}
                     </span>
                     <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60 leading-tight">
                        {heroTitle}
                     </h1>
                     <p className="text-zinc-400 max-w-xl mx-auto mb-8 text-lg">
                        {heroSubtitle}
                     </p>
                     <div className="flex justify-center gap-4">
                        <button className="px-6 py-3 bg-white text-black font-semibold rounded-lg hover:bg-zinc-200 transition-colors">Start Building</button>
                        <button className="px-6 py-3 border border-white/20 hover:bg-white/5 rounded-lg text-white transition-colors">View Demo</button>
                     </div>
                  </div>
                </section>

                {/* Features */}
                <section className="py-20 px-6 border-y border-white/5 bg-zinc-900/20">
                   <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="p-6 rounded-xl border border-white/10 bg-black/50 hover:border-purple-500/50 transition-colors cursor-default group">
                          <div className="w-10 h-10 bg-purple-500/10 text-purple-400 rounded-lg mb-4 flex items-center justify-center group-hover:bg-purple-500/20 transition-colors">
                             <Icons.Cpu className="w-5 h-5" />
                          </div>
                          <h3 className="font-semibold mb-2 text-white">Feature {i}</h3>
                          <p className="text-sm text-zinc-400">Advanced AI analysis of your repository structure.</p>
                        </div>
                      ))}
                   </div>
                </section>

                {/* PRICING SECTION (CONDITIONAL) */}
                {hasPricing && (
                  <section className="py-24 px-6 relative animate-in fade-in slide-in-from-bottom-8 duration-700">
                    <div className="text-center mb-16">
                      <h2 className="text-3xl font-bold mb-4">Simple Pricing</h2>
                      <p className="text-zinc-400">Start for free, scale when you need.</p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                      <div className="p-8 rounded-2xl border border-white/10 bg-zinc-900/50 hover:border-white/20 transition-colors">
                         <div className="text-xl font-medium mb-2 text-zinc-200">Starter</div>
                         <div className="text-3xl font-bold mb-6">$0</div>
                         <button className="w-full py-2 border border-white/20 rounded-lg hover:bg-white/10 text-sm font-medium transition-colors">Get Started</button>
                      </div>
                      <div className="p-8 rounded-2xl border border-purple-500/50 bg-purple-900/10 transform md:scale-105 shadow-2xl shadow-purple-900/20 relative">
                         <div className="absolute top-0 right-0 -mt-3 mr-3 bg-purple-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">POPULAR</div>
                         <div className="text-xl font-medium mb-2 text-purple-400">Pro</div>
                         <div className="text-3xl font-bold mb-6">$29</div>
                         <button className="w-full py-2 bg-white text-black rounded-lg hover:bg-zinc-200 text-sm font-bold transition-colors">Start Trial</button>
                      </div>
                      <div className="p-8 rounded-2xl border border-white/10 bg-zinc-900/50 hover:border-white/20 transition-colors">
                         <div className="text-xl font-medium mb-2 text-zinc-200">Enterprise</div>
                         <div className="text-3xl font-bold mb-6">Custom</div>
                         <button className="w-full py-2 border border-white/20 rounded-lg hover:bg-white/10 text-sm font-medium transition-colors">Contact</button>
                      </div>
                    </div>
                  </section>
                )}

                <footer className="py-12 px-6 border-t border-white/10 text-center text-zinc-600 text-sm">
                   &copy; 2024 Acme AI Inc.
                </footer>
              </div>
           </div>
        </div>
      </div>
    );
  }

  // DIFF MODE LOGIC
  const isDiff = mode === 'diff';
  const hasChanges = code !== originalCode;

  if (isDiff) {
    return (
        <div className="w-full h-full bg-[#050505] flex flex-col relative pb-24 md:pb-0">
            {/* Diff Banner */}
            {hasChanges ? (
                <div className="bg-purple-900/10 border-b border-purple-500/20 px-4 py-3 flex items-center justify-between animate-in slide-in-from-top-2 shrink-0 z-10">
                    <div className="flex items-center gap-2 text-purple-300 text-xs font-medium">
                        <Icons.GitBranch className="w-3.5 h-3.5" />
                        <span>Showing generated changes for {filename}</span>
                    </div>
                    <div className="flex gap-2">
                        {/* Global PR Action */}
                        <button onClick={onApprove} className="px-4 py-1.5 bg-green-600 hover:bg-green-500 text-white rounded-md text-xs font-bold transition-all shadow-lg shadow-green-900/20 flex items-center gap-2">
                            <Icons.CheckCircle2 className="w-3.5 h-3.5" /> Approve & Create PR
                        </button>
                    </div>
                </div>
            ) : (
                <div className="bg-[#09090b] border-b border-white/5 px-4 py-3 flex items-center gap-2 animate-in slide-in-from-top-2 shrink-0 z-10">
                    <Icons.CheckCircle2 className="w-4 h-4 text-zinc-500" />
                    <span className="text-zinc-500 text-xs font-medium">No uncommitted changes in this file.</span>
                </div>
            )}

            {/* Comparison Diff View */}
            <div className="flex-1 overflow-auto bg-[#050505] font-mono text-[13px]">
                <Highlight theme={themes.vsDark} code={originalCode} language={getLanguage(filename)}>
                  {({ tokens: oldTokens }) => (
                     <Highlight theme={themes.vsDark} code={code} language={getLanguage(filename)}>
                        {({ tokens: newTokens, getLineProps, getTokenProps }) => {
                            // 1. Calculate matching prefix
                            let start = 0;
                            const oldLinesStr = originalCode.split('\n');
                            const newLinesStr = code.split('\n');
                            const minLen = Math.min(oldLinesStr.length, newLinesStr.length);
                            
                            while(start < minLen && oldLinesStr[start] === newLinesStr[start]) {
                                start++;
                            }

                            // 2. Calculate matching suffix
                            let endOld = oldLinesStr.length - 1;
                            let endNew = newLinesStr.length - 1;

                            // Ensure we don't cross the start
                            while(endOld >= start && endNew >= start && oldLinesStr[endOld] === newLinesStr[endNew]) {
                                endOld--;
                                endNew--;
                            }

                            // 3. Render
                            return (
                                <div style={{ minWidth: '100%', display: 'table' }}>
                                    {/* Unchanged Top */}
                                    {oldTokens.slice(0, start).map((line, i) => (
                                        <div key={`pre-${i}`} className="table-row opacity-60 hover:opacity-100 transition-opacity">
                                            <span className="table-cell text-right pr-4 text-xs select-none w-12 text-zinc-700 align-top border-r border-white/5 bg-[#0c0c0e] py-0.5">{i + 1}</span>
                                            <span className="table-cell pl-4 text-zinc-400 py-0.5 whitespace-pre">
                                                {line.map((token, key) => <span key={key} {...getTokenProps({ token })} />)}
                                            </span>
                                        </div>
                                    ))}

                                    {/* Hunk Header / Inline Action */}
                                    {hasChanges && (
                                        <div className="table-row">
                                            <div className="table-cell border-r border-white/5 bg-[#0c0c0e]"></div>
                                            <div className="table-cell">
                                                <div className="mx-4 my-3 p-2 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-between animate-in fade-in zoom-in-95">
                                                    <div className="flex items-center gap-3">
                                                        <div className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold uppercase tracking-wider border border-blue-500/30">Hunk 1</div>
                                                        <span className="text-xs text-blue-200">
                                                            {endNew - start + 1 > 0 ? `Changes found at lines ${start + 1}-${endNew + 1}` : 'Deletion'}
                                                        </span>
                                                    </div>
                                                    <button 
                                                        onClick={onApprove}
                                                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-md transition-colors flex items-center gap-1.5 shadow-sm active:scale-95"
                                                    >
                                                        <Icons.Check className="w-3.5 h-3.5" /> Accept Change
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Removed Lines (Red) */}
                                    {hasChanges && oldTokens.slice(start, endOld + 1).map((line, i) => (
                                        <div key={`rem-${i}`} className="table-row bg-red-900/10">
                                            <span className="table-cell text-right pr-4 text-xs select-none w-12 text-red-500/50 align-top border-r border-red-500/20 bg-[#1a0f0f] py-0.5">{start + i + 1}</span>
                                            <span className="table-cell pl-4 py-0.5 whitespace-pre relative group">
                                                <span className="text-red-400 opacity-60 line-through decoration-red-500/30">
                                                    {line.map((token, key) => <span key={key} {...getTokenProps({ token })} />)}
                                                </span>
                                            </span>
                                        </div>
                                    ))}

                                    {/* Added Lines (Green) */}
                                    {hasChanges && newTokens.slice(start, endNew + 1).map((line, i) => (
                                        <div key={`add-${i}`} className="table-row bg-green-900/10">
                                            <span className="table-cell text-right pr-4 text-xs select-none w-12 text-green-500/50 align-top border-r border-green-500/20 bg-[#0f1a12] py-0.5">{start + i + 1}</span>
                                            <span className="table-cell pl-4 py-0.5 whitespace-pre relative">
                                                <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-green-500/50" />
                                                {line.map((token, key) => <span key={key} {...getTokenProps({ token })} />)}
                                            </span>
                                        </div>
                                    ))}

                                    {/* Unchanged Bottom */}
                                    {oldTokens.slice(endOld + 1).map((line, i) => (
                                        <div key={`post-${i}`} className="table-row opacity-60 hover:opacity-100 transition-opacity">
                                            {/* Line number maps to new file state */}
                                            <span className="table-cell text-right pr-4 text-xs select-none w-12 text-zinc-700 align-top border-r border-white/5 bg-[#0c0c0e] py-0.5">
                                                {endNew + 1 + i + 1}
                                            </span>
                                            <span className="table-cell pl-4 text-zinc-400 py-0.5 whitespace-pre">
                                                {line.map((token, key) => <span key={key} {...getTokenProps({ token })} />)}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            );
                        }}
                     </Highlight>
                  )}
                </Highlight>
            </div>
        </div>
    );
  }

  // STANDARD CODE VIEW
  return (
    <div className="w-full h-full bg-[#050505] flex flex-col relative pb-24 md:pb-0">
      <div className="flex-1 overflow-auto bg-[#050505] font-mono text-[13px]">
        <Highlight theme={themes.vsDark} code={code} language={getLanguage(filename)}>
            {({ className, style, tokens, getLineProps, getTokenProps }) => (
            <div style={{ minWidth: '100%', display: 'table' }}>
                {tokens.map((line, i) => (
                    <div key={i} {...getLineProps({ line })} className="table-row">
                        <span className="table-cell text-right pr-4 text-xs select-none w-12 text-zinc-700 align-top border-r border-white/5 bg-[#0c0c0e] py-0.5">
                            {i + 1}
                        </span>
                        <span className="table-cell pl-4 py-0.5 whitespace-pre text-zinc-300">
                            {line.map((token, key) => <span key={key} {...getTokenProps({ token })} />)}
                        </span>
                    </div>
                ))}
            </div>
            )}
        </Highlight>
      </div>
    </div>
  );
};

export default CodeViewer;
