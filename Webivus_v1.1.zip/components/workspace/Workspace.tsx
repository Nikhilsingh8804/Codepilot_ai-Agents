
import React, { useState, useEffect, useMemo } from 'react';
import { Project, User } from '../../types';
import { Icons } from '../ui/Icons';
import ChatInterface from './ChatInterface';
import CodeViewer from './CodeViewer';
import FileTree, { FileSystemItem } from './FileTree';

interface WorkspaceProps {
  project: Project;
  user: User;
  onLogout: () => void;
  onBack: () => void;
}

// A "Real" looking codebase matching the screenshot
const REAL_SAAS_FILES: Record<string, string> = {
  '.github/workflows/ci.yml': `name: CI

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  build:
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [18.x, 20.x]

    steps:
    - uses: actions/checkout@v4

    - name: Use Node.js \${{ matrix.node-version }}
      uses: actions/setup-node@v4
      with:
        node-version: \${{ matrix.node-version }}
        cache: 'npm'

    - name: Install dependencies
      run: npm ci

    - name: Lint
      run: npm run lint --if-present

    - name: Test
      run: npm test --if-present

    - name: Build
      run: npm run build --if-present
`,
  'src/app/page.tsx': `import React from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Hero } from '@/components/sections/Hero';
import { Features } from '@/components/sections/Features';
import { Footer } from '@/components/layout/Footer';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-purple-500/30">
      <Navbar />
      <main>
        <Hero />
        <Features />
      </main>
      <Footer />
    </div>
  );
}`,
  'src/components/layout/Navbar.tsx': `import React from 'react';
import { Button } from '@/components/ui/button';

export const Navbar = () => (
  <nav className="fixed top-0 w-full z-50 border-b border-white/10 bg-black/50 backdrop-blur-xl">
    <div className="container mx-auto px-6 h-16 flex items-center justify-between">
      <div className="font-bold text-xl tracking-tighter">Acme<span className="text-purple-500">AI</span></div>
      <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
        <a href="#" className="hover:text-white transition-colors">Features</a>
        <a href="#" className="hover:text-white transition-colors">Testimonials</a>
        <a href="#" className="hover:text-white transition-colors">Docs</a>
      </div>
      <div className="flex items-center gap-4">
        <a href="#" className="text-sm font-medium hover:text-white transition-colors text-zinc-400">Sign In</a>
        <Button variant="primary">Get Started</Button>
      </div>
    </div>
  </nav>
);`,
  'src/components/sections/Hero.tsx': `import React from 'react';
import { Button } from '@/components/ui/button';

export const Hero = () => (
  <section className="pt-32 pb-20 relative overflow-hidden">
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-purple-500/20 rounded-full blur-[120px] pointer-events-none" />
    <div className="container mx-auto px-6 text-center relative z-10">
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-purple-400 mb-8">
        <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
        v2.0 is now available
      </div>
      <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
        Manage your code <br /> with intelligent agents.
      </h1>
      <p className="text-lg text-zinc-400 max-w-2xl mx-auto mb-10">
        Stop writing boilerplate. Let our AI architect your codebase, optimize your database, and deploy to production in seconds.
      </p>
      <div className="flex items-center justify-center gap-4">
        <Button variant="primary" size="lg">Start Building</Button>
        <Button variant="outline" size="lg">View Demo</Button>
      </div>
    </div>
  </section>
);`,
  'src/components/sections/Features.tsx': `import React from 'react';

export const Features = () => (
  <section className="py-24 bg-zinc-900/30 border-y border-white/5">
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-3 gap-8">
        {[1, 2, 3].map((i) => (
          <div key={i} className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/50 transition-colors">
            <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center mb-4">
              <div className="w-6 h-6 bg-purple-500/50 rounded" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Intelligent Analysis</h3>
            <p className="text-zinc-400">Our agents deeply understand your code structure to provide context-aware suggestions.</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);`,
  'src/components/ui/button.tsx': `import React from 'react';

export const Button = ({ children, variant = 'primary', size = 'md' }: any) => {
  const base = "rounded-lg font-medium transition-all active:scale-95";
  const variants = {
    primary: "bg-white text-black hover:bg-zinc-200",
    outline: "border border-white/20 hover:bg-white/10 text-white"
  };
  const sizes = {
    md: "px-4 py-2 text-sm",
    lg: "px-8 py-3 text-base"
  };
  return (
    <button className={base + " " + variants[variant] + " " + sizes[size]}>
      {children}
    </button>
  );
};`,
  'src/app/globals.css': `@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  background: #000;
  color: #fff;
}`,
};

// Helper to build file tree structure
const buildFileTree = (files: Record<string, string>): FileSystemItem[] => {
  const root: FileSystemItem[] = [];
  const paths = Object.keys(files).sort();

  paths.forEach(path => {
    const parts = path.split('/');
    let currentLevel = root;

    parts.forEach((part, index) => {
      const isFile = index === parts.length - 1;
      let existingItem = currentLevel.find(i => i.name === part);

      if (!existingItem) {
        existingItem = {
          id: path.split('/').slice(0, index + 1).join('/'),
          name: part,
          type: isFile ? 'file' : 'folder',
          path: isFile ? path : undefined,
          children: isFile ? undefined : []
        };
        currentLevel.push(existingItem);
      }

      if (!isFile && existingItem.children) {
        currentLevel = existingItem.children;
      }
    });
  });

  // Sort folders first
  const sortItems = (items: FileSystemItem[]) => {
      items.sort((a, b) => {
          if (a.type === b.type) return a.name.localeCompare(b.name);
          return a.type === 'folder' ? -1 : 1;
      });
      items.forEach(i => {
          if (i.children) sortItems(i.children);
      });
  };

  sortItems(root);
  return root;
};

type ViewMode = 'chat' | 'code' | 'preview' | 'changes';

const Workspace: React.FC<WorkspaceProps> = ({ project, user, onLogout, onBack }) => {
  // Navigation State
  const [activeView, setActiveView] = useState<ViewMode>('chat'); // For Mobile mainly, or primary content on Desktop
  const [isChatSidebarOpen, setIsChatSidebarOpen] = useState(true); // Desktop only
  const [isFileTreeOpen, setIsFileTreeOpen] = useState(true);
  
  // File System State
  const [activeFile, setActiveFile] = useState<string>('src/app/page.tsx');
  const [files, setFiles] = useState<Record<string, string>>({ ...REAL_SAAS_FILES, ...(project.files || {}) });
  
  // AI/Diff State
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);

  // Git State (Lifted from ChatInterface)
  const [activeFeatureBranch, setActiveFeatureBranch] = useState<string | null>(null);
  const [unsavedChangeCount, setUnsavedChangeCount] = useState(0);
  
  // Responsive Check
  const [isMobile, setIsMobile] = useState(false);

  // Memoize file tree structure
  const fileTreeItems = useMemo(() => buildFileTree(files), [files]);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleCodeGenerated = (file: string, code: string, diff?: string) => {
    setGeneratedCode(code);
    setActiveFile(file);
    
    // Automatically switch to Changes view to review
    setActiveView('changes');
  };

  const handleApproveChanges = () => {
    if (generatedCode) {
      setFiles(prev => ({ ...prev, [activeFile]: generatedCode }));
      setGeneratedCode(null);
      setActiveView('code'); // Go back to code view
    }
  };

  const handleCommit = () => {
     setGeneratedCode(null);
     setActiveView('code');
  };

  // --- MODERN DOCK NAVIGATION ---
  const Dock = () => (
    <div className="fixed bottom-4 md:bottom-6 left-1/2 -translate-x-1/2 z-[60] animate-in slide-in-from-bottom-6 duration-500 w-auto max-w-[90vw]">
      <div className="flex items-center gap-1 p-1.5 bg-[#09090b]/90 backdrop-blur-xl border border-white/10 rounded-full shadow-[0_0_40px_rgba(0,0,0,0.5)] ring-1 ring-white/5 overflow-x-auto no-scrollbar">
        
        {/* Chat / Assistant (Renamed to Chat) */}
        <button 
          onClick={() => {
             if (isMobile) setActiveView('chat');
             else setIsChatSidebarOpen(!isChatSidebarOpen);
          }}
          className={`
             relative px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 group whitespace-nowrap
             ${(isMobile && activeView === 'chat') || (!isMobile && isChatSidebarOpen) 
                ? 'bg-white text-black shadow-lg shadow-white/10 font-bold' 
                : 'hover:bg-white/10 text-zinc-400 hover:text-white font-medium'}
          `}
        >
          <Icons.MessageSquare className="w-4 h-4" />
          <span className="text-xs">Chat</span>
        </button>

        {/* Preview (Moved before Code) */}
        <button 
          onClick={() => setActiveView('preview')}
          className={`
             relative px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 whitespace-nowrap
             ${activeView === 'preview' ? 'bg-white text-black shadow-lg shadow-white/10 font-bold' : 'hover:bg-white/10 text-zinc-400 hover:text-white font-medium'}
          `}
        >
          <Icons.Play className="w-3.5 h-3.5 fill-current" />
          <span className="text-xs">Preview</span>
        </button>
        
        {/* Code Editor */}
        <button 
          onClick={() => setActiveView('code')}
          className={`
             relative px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 whitespace-nowrap
             ${activeView === 'code' ? 'bg-white text-black shadow-lg shadow-white/10 font-bold' : 'hover:bg-white/10 text-zinc-400 hover:text-white font-medium'}
          `}
        >
          <Icons.Code2 className="w-4 h-4" />
          <span className="text-xs">Code</span>
        </button>

        {/* Changes (Only visible if diff exists) */}
        {generatedCode && (
           <button 
             onClick={() => setActiveView('changes')}
             className={`
                relative px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 whitespace-nowrap
                ${activeView === 'changes' ? 'bg-white text-black shadow-lg shadow-white/10 font-bold' : 'hover:bg-white/10 text-green-400 hover:text-green-300 font-medium'}
             `}
           >
             <Icons.GitBranch className="w-3.5 h-3.5" />
             <span className="text-xs">Changes</span>
           </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-zinc-400 font-sans overflow-hidden selection:bg-purple-500/30">
      
      {/* --- GLOBAL HEADER --- */}
      <header className="h-14 bg-[#050505] border-b border-white/5 flex items-center justify-between px-4 shrink-0 z-40 relative">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="flex items-center gap-1 text-sm font-medium text-zinc-500 hover:text-white transition-colors pr-3 border-r border-white/10"
          >
            <Icons.ChevronRight className="w-4 h-4 rotate-180" />
            Back
          </button>
          <div className="flex items-center gap-2">
             <div className="w-6 h-6 rounded bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-[10px] font-bold text-white shadow-inner">
                {project.name.substring(0,2).toUpperCase()}
             </div>
             <span className="text-sm font-bold text-white">{project.name}</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
           {/* Visual Branch Indicator */}
           <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all cursor-pointer group ${
             activeFeatureBranch
               ? 'bg-purple-500/10 border-purple-500/20 hover:border-purple-500/40' 
               : 'bg-[#0c0c0e] border-white/10 hover:border-white/20'
           }`}>
              <Icons.GitBranch className={`w-3.5 h-3.5 ${activeFeatureBranch ? 'text-purple-400' : 'text-zinc-500'}`} />
              <span className={`text-xs font-mono font-semibold transition-colors ${activeFeatureBranch ? 'text-zinc-200' : 'text-zinc-500'}`}>
                {activeFeatureBranch || project.branch || 'main'}
              </span>
           </div>

           {/* Deployment Status Pill */}
           <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-full bg-zinc-900 border border-white/5 opacity-60">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <span className="text-[10px] font-medium text-zinc-400">v2.4.0 deployed</span>
           </div>
           
           <img src={user.avatarUrl} alt="User" className="w-8 h-8 rounded-full border border-white/10 bg-zinc-800" />
        </div>
      </header>

      {/* --- MAIN WORKSPACE AREA --- */}
      <main className="flex-1 flex overflow-hidden relative">
        
        {/* 1. CHAT PANEL (Sidebar on Desktop, Full view on Mobile) */}
        <div 
           className={`
              flex flex-col border-r border-white/5 bg-[#09090b] transition-all duration-300 ease-in-out shrink-0
              ${isMobile 
                  ? (activeView === 'chat' ? 'absolute inset-0 z-30 w-full' : 'hidden') 
                  : (isChatSidebarOpen ? 'w-[400px] translate-x-0' : 'w-0 -translate-x-full opacity-0 overflow-hidden border-none')
              }
           `}
        >
           <ChatInterface 
              files={files} 
              onCodeGenerated={handleCodeGenerated}
              onCommit={handleCommit}
              // Pass Git state down
              activeFeatureBranch={activeFeatureBranch}
              setActiveFeatureBranch={setActiveFeatureBranch}
              unsavedChangeCount={unsavedChangeCount}
              setUnsavedChangeCount={setUnsavedChangeCount}
              projectRepo={project.repoUrl || 'user/repo'}
              projectBranch={project.branch}
           />
        </div>

        {/* 2. CONTENT PANEL (Code / Preview / Diff) */}
        <div className="flex-1 flex flex-row min-w-0 bg-[#050505] relative z-0 overflow-hidden">
           
           {/* FILE TREE SIDEBAR (Code View Only) */}
           {!isMobile && activeView === 'code' && isFileTreeOpen && (
              <div className="w-64 bg-[#09090b] border-r border-white/5 flex flex-col shrink-0 animate-in slide-in-from-left-4 duration-300">
                 <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 shrink-0">
                    <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Explorer</span>
                    <button onClick={() => setIsFileTreeOpen(false)} className="text-zinc-600 hover:text-white transition-colors">
                       <Icons.X className="w-3.5 h-3.5" />
                    </button>
                 </div>
                 <div className="flex-1 overflow-hidden">
                    <FileTree 
                       items={fileTreeItems}
                       activeFileId={activeFile}
                       onSelect={(item) => {
                           if (item.type === 'file' && item.path) setActiveFile(item.path);
                       }}
                    />
                 </div>
              </div>
           )}

           <div className="flex-1 flex flex-col min-w-0">
               {/* File Tabs (Only show if we are in Code/Diff mode and on Desktop) */}
               {!isMobile && activeView !== 'preview' && (
                  <div className="h-10 border-b border-white/5 bg-[#050505] flex items-center px-2 gap-2 overflow-x-auto no-scrollbar shrink-0">
                     {activeView === 'code' && !isFileTreeOpen && (
                        <button 
                           onClick={() => setIsFileTreeOpen(true)}
                           className="p-1.5 text-zinc-500 hover:text-white rounded-md hover:bg-white/5 transition-colors"
                           title="Open File Explorer"
                        >
                            <Icons.FolderOpen className="w-4 h-4" />
                        </button>
                     )}
                     <button className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#09090b] border border-white/5 text-xs text-white shadow-sm">
                        <Icons.FileCode className="w-3.5 h-3.5 text-blue-400" />
                        {activeFile.split('/').pop()}
                        <Icons.X className="w-3 h-3 text-zinc-600 hover:text-white ml-1" />
                     </button>
                  </div>
               )}

               <div className="flex-1 overflow-hidden relative">
                  {/* Using CSS display instead of conditional rendering to preserve state if needed, 
                      though for CodeViewer heavily stateful, conditional might be cleaner. 
                      Let's use conditional but careful about re-mounts. */}
                  
                  {activeView === 'code' && (
                     <CodeViewer 
                       mode="code"
                       code={files[activeFile] || '// Select a file'}
                       originalCode={files[activeFile]} // No diff in edit mode
                       filename={activeFile}
                       files={files}
                       onApprove={() => {}} 
                     />
                  )}

                  {activeView === 'changes' && (
                     <CodeViewer 
                       mode="diff"
                       code={generatedCode || files[activeFile]}
                       originalCode={files[activeFile]}
                       filename={activeFile}
                       files={files}
                       onApprove={handleApproveChanges}
                     />
                  )}

                  {activeView === 'preview' && (
                     <CodeViewer 
                       mode="preview"
                       code={generatedCode || files[activeFile]} // Preview generated code if available
                       originalCode={files[activeFile]}
                       filename={activeFile}
                       files={{...files, [activeFile]: generatedCode || files[activeFile]}}
                       onApprove={() => {}}
                     />
                  )}
               </div>
           </div>
        </div>

      </main>

      {/* --- FLOATING DOCK --- */}
      <Dock />

    </div>
  );
};

export default Workspace;
