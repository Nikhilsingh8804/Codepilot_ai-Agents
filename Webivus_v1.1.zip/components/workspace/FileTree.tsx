
import React, { useState } from 'react';
import { Icons } from '../ui/Icons';

export interface FileSystemItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileSystemItem[];
  path?: string; // Helpers for flattened access if needed
}

interface FileTreeProps {
  items: FileSystemItem[];
  activeFileId: string | null;
  onSelect: (item: FileSystemItem) => void;
  depth?: number;
}

const FileTreeNode: React.FC<{
  item: FileSystemItem;
  activeFileId: string | null;
  onSelect: (item: FileSystemItem) => void;
  depth: number;
}> = ({ item, activeFileId, onSelect, depth }) => {
  const [isOpen, setIsOpen] = useState(item.name === 'src' || item.name === 'app' || item.name === 'components');

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (item.type === 'folder') {
      setIsOpen(!isOpen);
    } else {
      onSelect(item);
    }
  };

  const isActive = item.id === activeFileId;

  return (
    <div>
      <div
        onClick={handleClick}
        className={`flex items-center gap-2 py-1 px-2 cursor-pointer select-none transition-colors text-xs font-medium tracking-wide
          ${isActive ? 'bg-white/5 text-white' : 'text-zinc-500 hover:text-white hover:bg-white/5'}
        `}
        style={{ paddingLeft: `${depth * 16 + 12}px` }}
      >
        <span className="opacity-70 shrink-0">
          {item.type === 'folder' ? (
             isOpen ? <Icons.ChevronDown className="w-3 h-3" /> : <Icons.ChevronRight className="w-3 h-3" />
          ) : (
             <span className="w-3 inline-block" />
          )}
        </span>
        
        {item.type === 'folder' ? (
           <Icons.Folder className={`w-3.5 h-3.5 ${isOpen ? 'text-blue-500' : 'text-blue-500/80'}`} />
        ) : (
           <Icons.FileCode className="w-3.5 h-3.5 text-zinc-600" />
        )}
        
        <span className="truncate">{item.name}</span>
      </div>

      {item.type === 'folder' && isOpen && item.children && (
        <div>
          {item.children.map((child) => (
            <FileTreeNode
              key={child.id}
              item={child}
              activeFileId={activeFileId}
              onSelect={onSelect}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const FileTree: React.FC<FileTreeProps> = ({ items, activeFileId, onSelect }) => {
  return (
    <div className="w-full h-full overflow-y-auto py-2">
      {items.map((item) => (
        <FileTreeNode
          key={item.id}
          item={item}
          activeFileId={activeFileId}
          onSelect={onSelect}
          depth={0}
        />
      ))}
    </div>
  );
};

export default FileTree;
