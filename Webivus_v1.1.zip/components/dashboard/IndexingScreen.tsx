
import React, { useEffect, useState, useRef } from 'react';
import { Icons } from '../ui/Icons';
import { Project } from '../../types';

interface IndexingScreenProps {
  project: Project;
  onComplete: (indexedProject: Project) => void;
}

const IndexingScreen: React.FC<IndexingScreenProps> = ({ project, onComplete }) => {
  const [progress, setProgress] = useState(0);
  
  // Simulation Logs
  const [logs, setLogs] = useState<{ time: string; status: string; message: string; color: string; subtext?: string }[]>([
    { time: "09:42:01", status: "SUCCESS", message: "Initialized local repository cache...", color: "text-green-500" }
  ]);

  // Animation Refs
  const logContainerRef = useRef<HTMLDivElement>(null);

  // Constants for SVG Circle
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  useEffect(() => {
    // Scroll logs to bottom when added
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        
        // Add dynamic logs based on progress thresholds
        const currentProgress = prev + 1;
        const now = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        if (currentProgress === 10) {
            setLogs(l => [...l, { time: now, status: "SUCCESS", message: `Fetching git history (depth=1)...`, color: "text-green-500" }]);
        }
        if (currentProgress === 25) {
            setLogs(l => [...l, { 
                time: now, 
                status: "RUNNING", 
                message: "Analyzing src/components/ui/*.tsx", 
                color: "text-purple-500",
                subtext: "- Identified 42 Tailwind modules\n- Mapping dependency tree..."
            }]);
        }
        if (currentProgress === 45) {
            setLogs(l => [...l, { time: now, status: "RUNNING", message: "Parsing server actions in @/app/actions", color: "text-purple-500" }]);
        }
        if (currentProgress === 60) {
            setLogs(l => [...l, { time: now, status: "WARN", message: "Missing type definitions for 'auth-js'", color: "text-yellow-500" }]);
        }
        if (currentProgress === 75) {
            setLogs(l => [...l, { time: now, status: "RUNNING", message: "Detecting database schemas (Prisma)...", color: "text-purple-500" }]);
        }
        if (currentProgress === 90) {
            setLogs(l => [...l, { time: now, status: "INFO", message: "Scanning filesystem for secret keys...", color: "text-blue-400" }]);
        }

        return currentProgress;
      });
    }, 60); // Roughly 6 seconds total

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      setTimeout(() => {
        onComplete({
          ...project,
          routerType: 'App Router',
          stylingSystem: 'Tailwind CSS',
          componentCount: 142,
          pageCount: 12,
          apiRouteCount: 8,
          issues: [
            'Missing meta description on /about page',
            'No robots.txt file found',
            'Homepage title too generic'
          ]
        });
      }, 1500);
    }
  }, [progress, onComplete, project]);

  return (
    <div className="relative min-h-screen bg-[#050505] text-white font-sans overflow-hidden flex flex-col items-center justify-center p-6">
      
      {/* Background Radial Glow */}
      <div className="fixed inset-0 pointer-events-none" style={{ background: 'radial-gradient(circle at center, rgba(168, 85, 247, 0.15) 0%, transparent 70%)' }}></div>

      <div className="relative z-10 w-full max-w-4xl flex flex-col items-center space-y-12">
        
        {/* Header Text */}
        <div className="text-center space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h1 className="text-4xl lg:text-5xl font-bold tracking-tight">
                Importing <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500/50">{project.name}</span>
            </h1>
            <p className="text-zinc-400 max-w-md mx-auto">
                Webivus is analyzing your codebase to understand your project structure and dependencies.
            </p>
        </div>

        {/* Central Progress Ring */}
        <div className="relative flex items-center justify-center w-[320px] h-[320px] animate-in zoom-in-95 duration-1000">
            {/* Progress Ring - z-index 10 */}
            <div className="relative z-10">
                <svg className="w-64 h-64 drop-shadow-[0_0_25px_rgba(168,85,247,0.3)] transform -rotate-90">
                    {/* Track Circle */}
                    <circle 
                        className="text-zinc-800" 
                        cx="128" cy="128" r={radius} 
                        fill="#050505" 
                        stroke="currentColor" 
                        strokeWidth="6" 
                    />
                    {/* Progress Circle */}
                    <circle 
                        className="text-purple-600 transition-all duration-300 ease-linear" 
                        cx="128" cy="128" r={radius} 
                        fill="transparent" 
                        stroke="currentColor" 
                        strokeWidth="6" 
                        strokeLinecap="round" 
                        strokeDasharray={circumference} 
                        strokeDashoffset={strokeDashoffset} 
                    />
                </svg>

                {/* Center Content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center space-y-2 pointer-events-none">
                    <div className="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center border border-purple-500/20 animate-pulse">
                        <Icons.Cpu className="w-8 h-8 text-purple-500" />
                    </div>
                    <div className="text-3xl font-bold font-mono">{progress}%</div>
                    <div className="text-[10px] uppercase tracking-widest text-zinc-500 font-medium">Scanning Assets</div>
                </div>
            </div>

            {/* Decorative Rings */}
            <div className="absolute w-[280px] h-[280px] border border-dashed border-zinc-800 rounded-full animate-[spin_12s_linear_infinite] z-0"></div>
            <div className="absolute w-[320px] h-[320px] border border-zinc-800/30 rounded-full z-0"></div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-12 w-full max-w-lg border-t border-b border-white/5 py-6">
            <div className="text-center">
                <div className="text-2xl font-semibold text-green-500">142</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider mt-1">Components</div>
            </div>
            <div className="text-center">
                <div className="text-2xl font-semibold text-purple-500">12</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider mt-1">API Routes</div>
            </div>
            <div className="text-center">
                <div className="text-2xl font-semibold text-zinc-300">8</div>
                <div className="text-xs text-zinc-500 uppercase tracking-wider mt-1">Server Actions</div>
            </div>
        </div>

        {/* Terminal Section (Centered Below) */}
        <div className="w-full max-w-2xl">
            <div className="w-full h-48 bg-[#09090b]/80 backdrop-blur-xl border border-white/10 rounded-xl flex flex-col overflow-hidden shadow-2xl relative">
                <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/5">
                    <div className="flex space-x-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                    </div>
                    <div className="text-[10px] font-mono text-zinc-500 flex items-center">
                        <Icons.Terminal className="w-3 h-3 mr-2" />
                        ANALYSIS_LOG
                    </div>
                </div>

                <div ref={logContainerRef} className="flex-1 p-4 font-mono text-xs space-y-2 overflow-y-auto scrollbar-thin scrollbar-thumb-zinc-700 scrollbar-track-transparent">
                    {logs.map((log, i) => (
                        <div key={i} className="animate-in fade-in slide-in-from-bottom-1 duration-200">
                            <div className="flex gap-2">
                                <span className="text-zinc-600 shrink-0">{log.time}</span>
                                <span className={`font-bold shrink-0 ${log.color}`}>{log.status}</span>
                                <span className="text-zinc-400 break-words">{log.message}</span>
                            </div>
                        </div>
                    ))}
                    {progress < 100 && (
                        <div className="flex space-x-2 animate-pulse mt-2">
                            <span className="text-zinc-600 shrink-0">...</span>
                            <span className="inline-block w-1.5 h-3 bg-purple-500 ml-1"></span>
                        </div>
                    )}
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default IndexingScreen;
