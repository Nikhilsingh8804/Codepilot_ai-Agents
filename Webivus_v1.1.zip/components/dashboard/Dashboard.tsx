
import React, { useState } from 'react';
import { Icons } from '../ui/Icons';
import { User, Project } from '../../types';

interface DashboardProps {
  user: User;
  onConnectGithub: (token?: string) => void;
  onImportProject: () => void;
  onSelectProject: (project: Project) => void;
  projects: Project[];
}

const Dashboard: React.FC<DashboardProps> = ({ 
  user, 
  onConnectGithub, 
  onImportProject, 
  onSelectProject,
  projects 
}) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [token, setToken] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const handleConnect = () => {
    setIsConnecting(true);
    setTimeout(() => {
      onConnectGithub(token);
      setIsConnecting(false);
    }, 1500);
  };

  const filteredProjects = projects.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!user.githubConnected) {
    return (
      <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center p-4 relative overflow-hidden text-zinc-400">
         <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />
         <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="w-full max-w-xl bg-[#09090b] border border-white/10 rounded-2xl p-8 md:p-10 shadow-2xl text-center space-y-8 relative z-10 backdrop-blur-xl">
           <div className="mx-auto w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 shadow-inner">
             <Icons.Github className="w-8 h-8 text-white" />
           </div>

           <div className="space-y-2">
             <h1 className="text-2xl font-bold tracking-tight text-white">Connect to GitHub</h1>
             <p className="text-zinc-500">
               Webivus needs access to your repositories to analyze code and generate PRs.
             </p>
           </div>

           <div className="bg-[#0c0c0e] rounded-xl p-4 text-left space-y-3 border border-white/5">
             {[
               "Read access to code repositories",
               "Create branches and pull requests",
               "Webhooks for real-time updates"
             ].map((item, i) => (
               <div key={i} className="flex items-center gap-3 text-sm text-zinc-300">
                 <Icons.CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                 {item}
               </div>
             ))}
           </div>

           <div className="space-y-4">
              <input 
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                placeholder="Personal Access Token (Optional)"
                className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-purple-500 transition-all text-center text-white placeholder:text-zinc-600"
              />
              
             <button
               onClick={handleConnect}
               disabled={isConnecting}
               className="w-full py-3 bg-white hover:bg-zinc-200 text-black rounded-lg font-medium transition-all flex items-center justify-center gap-2"
             >
               {isConnecting ? <Icons.Loader2 className="w-4 h-4 animate-spin" /> : <Icons.Github className="w-4 h-4" />}
               {isConnecting ? 'Connecting...' : 'Authorize GitHub'}
             </button>
             
             <p className="text-xs text-zinc-600">
               By connecting, you agree to our Terms of Service.
             </p>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-400 flex flex-col md:flex-row font-sans selection:bg-purple-500/30">
      
      <header className="md:hidden h-14 border-b border-white/10 bg-[#050505] sticky top-0 z-40 flex items-center justify-between px-4">
        <div className="flex items-center gap-2 font-bold text-base text-white tracking-tight">
           <img src="/logos.svg" alt="" className="h-8 w-auto block" />
           <span>Webivus</span>
        </div>
        <button className="relative">
           <img src={user.avatarUrl} alt="User" className="w-8 h-8 rounded-full border border-white/10 bg-zinc-800" />
           <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-[#050505] rounded-full"></div>
        </button>
      </header>

      <aside className="hidden md:flex w-64 border-r border-white/10 bg-[#09090b] flex-col shrink-0 sticky top-0 h-screen">
        <div className="h-16 flex items-center px-6 gap-3 font-bold text-lg tracking-tight border-b border-white/10 text-white">
           <img src="/logos.svg" alt="" className="h-8 w-auto block" />
           Webivus
        </div>

        <div className="p-4 space-y-1">
          <div className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest px-2 mb-2">Platform</div>
          {[
            { id: 'overview', icon: Icons.Layout, label: 'Overview' },
            { id: 'activity', icon: Icons.Terminal, label: 'Activity' },
            { id: 'domains', icon: Icons.Smartphone, label: 'Domains' }, 
            { id: 'usage', icon: Icons.RefreshCw, label: 'Usage' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.id ? 'bg-white/10 text-white' : 'text-zinc-500 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </div>

        <div className="p-4 space-y-1 mt-auto border-t border-white/10">
          <button className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-zinc-500 hover:text-white hover:bg-white/5 transition-colors">
            <Icons.Settings className="w-4 h-4" />
            Settings
          </button>
           <div className="pt-4 flex items-center gap-3 px-2">
             <img src={user.avatarUrl} alt="User" className="w-8 h-8 rounded-full border border-white/10" />
             <div className="flex-1 min-w-0">
               <div className="text-sm font-medium truncate text-white">{user.name}</div>
               <div className="text-xs text-zinc-600 truncate">{user.email}</div>
             </div>
           </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-[#050505] pb-28 md:pb-0 relative">
        <header className="hidden md:flex h-16 border-b border-white/10 items-center justify-between px-8 bg-[#050505]/80 backdrop-blur sticky top-0 z-20">
           <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-zinc-500">Personal / Overview</span>
           </div>
           <div className="flex items-center gap-4">
             <div className="relative">
               <Icons.Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
               <input 
                 type="text" 
                 placeholder="Search projects..." 
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 className="w-64 h-9 pl-9 pr-4 bg-[#09090b] border border-white/10 rounded-full text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500 transition-all placeholder:text-zinc-600"
               />
             </div>
             <button 
                onClick={onImportProject}
                className="h-9 px-4 bg-white text-black hover:bg-zinc-200 rounded-full text-sm font-bold transition-colors flex items-center gap-2"
             >
               <Icons.Plus className="w-4 h-4" />
               New Project
             </button>
           </div>
        </header>

        <div className="md:hidden sticky top-14 z-30 bg-[#050505] border-b border-white/5 px-4 py-3 space-y-3">
             <div className="flex gap-3">
                 <div className="relative flex-1">
                    <Icons.Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input 
                        type="text" 
                        placeholder="Search..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full h-10 pl-10 pr-4 bg-[#09090b] border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder:text-zinc-600"
                    />
                 </div>
                 <button 
                    onClick={onImportProject}
                    className="h-10 w-10 bg-white text-black rounded-xl flex items-center justify-center shadow-lg shadow-white/5 active:scale-95 transition-transform"
                 >
                    <Icons.Plus className="w-5 h-5" />
                 </button>
             </div>
        </div>

        <div className="p-4 md:p-8 max-w-7xl w-full mx-auto space-y-6 md:space-y-8">
            {projects.length > 0 && (
                <div 
                  className="flex overflow-x-auto pb-4 gap-3 -mx-4 px-4 md:grid md:grid-cols-3 md:gap-4 md:mx-0 md:px-0 md:pb-0 snap-x snap-mandatory"
                  style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                >
                     <div className="snap-center shrink-0 w-[70vw] md:w-auto p-4 md:p-5 rounded-2xl border border-white/10 bg-[#09090b] relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
                        <div className="text-xs text-zinc-500 mb-1 font-medium flex items-center gap-2"><Icons.Layout className="w-3.5 h-3.5" /> Total Projects</div>
                        <div className="text-2xl md:text-3xl font-bold text-white tracking-tight">{projects.length}</div>
                     </div>
                     <div className="snap-center shrink-0 w-[70vw] md:w-auto p-4 md:p-5 rounded-2xl border border-white/10 bg-[#09090b] relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
                        <div className="text-xs text-zinc-500 mb-1 font-medium flex items-center gap-2"><Icons.Zap className="w-3.5 h-3.5" /> Deployments</div>
                        <div className="text-2xl md:text-3xl font-bold text-white tracking-tight">{projects.length * 3 + 12}</div>
                     </div>
                     <div className="snap-center shrink-0 w-[70vw] md:w-auto p-4 md:p-5 rounded-2xl border border-white/10 bg-[#09090b] relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
                        <div className="text-xs text-zinc-500 mb-1 font-medium flex items-center gap-2"><Icons.RefreshCw className="w-3.5 h-3.5" /> Avg Build Time</div>
                        <div className="text-2xl md:text-3xl font-bold text-white tracking-tight">45s</div>
                     </div>
                </div>
            )}

            <div className="space-y-4">
                <div className="flex items-center justify-between">
                    <h2 className="text-lg md:text-xl font-bold text-white">Your Projects</h2>
                    {projects.length > 0 && <button className="text-xs text-purple-400 font-medium md:hidden">View All</button>}
                </div>
                
                {projects.length === 0 ? (
                    <div className="border border-dashed border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center text-center bg-[#09090b]/50 min-h-[300px]">
                        <div className="w-16 h-16 bg-[#0c0c0e] border border-white/10 rounded-full flex items-center justify-center mb-4 shadow-inner">
                            <Icons.Plus className="w-6 h-6 text-zinc-500" />
                        </div>
                        <h3 className="text-lg font-bold text-white mb-2">No projects yet</h3>
                        <p className="text-sm text-zinc-500 max-w-xs mb-6 leading-relaxed">
                            Import a Git repository to start deploying and editing with Webivus AI.
                        </p>
                        <button 
                            onClick={onImportProject}
                            className="w-full md:w-auto px-8 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-purple-900/20 active:scale-95"
                        >
                            Import Project
                        </button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                        {filteredProjects.map((project) => (
                           <div 
                             key={project.id}
                             onClick={() => onSelectProject(project)}
                             className="group flex flex-col bg-[#09090b] border border-white/10 rounded-xl hover:border-purple-500/50 transition-all cursor-pointer overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-purple-900/10 active:scale-[0.98] md:active:scale-100"
                           >
                             <div className="p-4 md:p-5 border-b border-white/5">
                                <div className="flex items-start justify-between mb-3">
                                   <div className="flex items-center gap-3">
                                     <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-white/10 to-transparent flex items-center justify-center border border-white/10 text-white shrink-0">
                                       {project.framework === 'Next.js' ? <div className="text-xl font-bold">N</div> : <Icons.Code2 className="w-5 h-5" />}
                                     </div>
                                     <div className="min-w-0">
                                       <h3 className="font-semibold text-white group-hover:text-purple-400 transition-colors truncate">{project.name}</h3>
                                       <div className="text-xs text-zinc-500 truncate">{project.repoUrl || 'local/repo'}</div>
                                     </div>
                                   </div>
                                   <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-[10px] text-green-400 font-medium shrink-0">
                                     <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                                     Ready
                                   </div>
                                </div>
                                <div className="text-xs text-zinc-500 line-clamp-1">
                                  {project.description || "No description provided."}
                                </div>
                             </div>

                             <div className="mt-auto p-3 md:p-4 bg-white/[0.02]">
                                <div className="flex items-center gap-2 text-xs text-zinc-400 font-mono mb-2">
                                  <Icons.GitBranch className="w-3 h-3" />
                                  <span className="truncate">{project.branch}</span>
                                  <span className="text-zinc-600">•</span>
                                  <span>3a2f1c0</span>
                                  <span className="ml-auto text-[10px] text-zinc-600">2h ago</span>
                                </div>
                                <div className="text-xs text-zinc-500 truncate">
                                  Last commit: Update dashboard configuration
                                </div>
                             </div>
                           </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
      </main>

      <nav className="md:hidden fixed bottom-5 left-4 right-4 h-16 bg-[#0c0c0e]/90 backdrop-blur-xl border border-white/10 rounded-2xl flex items-center justify-between px-2 shadow-2xl z-50 ring-1 ring-white/5">
          {[
            { id: 'overview', icon: Icons.Layout, label: 'Home' },
            { id: 'activity', icon: Icons.Terminal, label: 'Activity' },
            { id: 'import', icon: Icons.Plus, label: 'New', isAction: true },
            { id: 'usage', icon: Icons.RefreshCw, label: 'Usage' },
            { id: 'settings', icon: Icons.Settings, label: 'Settings' },
          ].map((item) => {
             if (item.isAction) {
                 return (
                    <button key={item.id} onClick={onImportProject} className="flex flex-col items-center justify-center w-14 h-full -mt-6">
                        <div className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center shadow-lg shadow-white/20 active:scale-95 transition-transform border-4 border-[#050505]">
                            <item.icon className="w-6 h-6" />
                        </div>
                    </button>
                 )
             }
             const isActive = activeTab === item.id;
             return (
                <button 
                  key={item.id} 
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center justify-center w-14 h-full gap-1 transition-all ${isActive ? 'text-white' : 'text-zinc-600'}`}
                >
                    <div className={`p-1.5 rounded-xl transition-all ${isActive ? 'bg-white/10' : 'bg-transparent'}`}>
                        <item.icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                    </div>
                </button>
             )
          })}
      </nav>
    </div>
  );
};

export default Dashboard;
