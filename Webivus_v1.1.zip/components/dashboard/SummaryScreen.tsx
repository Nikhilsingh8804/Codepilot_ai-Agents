
import React from 'react';
import { Project } from '../../types';
import { Icons } from '../ui/Icons';

interface SummaryScreenProps {
  project: Project;
  onContinue: () => void;
}

const SummaryScreen: React.FC<SummaryScreenProps> = ({ project, onContinue }) => {
  return (
    <div className="min-h-screen bg-[#050505] text-zinc-400 font-sans selection:bg-purple-500/30 overflow-y-auto">
      
      {/* Header */}
      <header className="h-16 border-b border-white/5 bg-[#050505]/80 backdrop-blur sticky top-0 z-40 flex items-center justify-between px-6 md:px-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-[10px] font-bold text-white shadow-inner">
             {project.name.substring(0,2).toUpperCase()}
          </div>
          <div className="flex flex-col">
              <span className="text-sm font-bold text-white">{project.name}</span>
              <span className="text-xs text-zinc-500 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span> Active Analysis
              </span>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
             <button className="text-xs font-medium text-zinc-500 hover:text-white transition-colors">History</button>
             <button className="text-xs font-medium text-zinc-500 hover:text-white transition-colors">Share</button>
             <div className="h-4 w-px bg-white/10 mx-1"></div>
             <button onClick={onContinue} className="px-4 py-1.5 bg-white text-black hover:bg-zinc-200 rounded-lg text-xs font-bold transition-colors">
                Enter Workspace
             </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 md:p-10 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          {/* Hero Audit Banner */}
          <div className="relative rounded-2xl border border-white/10 bg-[#09090b] overflow-hidden p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 via-blue-500 to-green-500"></div>
              <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-purple-500/10 rounded-full blur-[100px] -mr-20 -mt-20 pointer-events-none" />

              <div className="space-y-4 relative z-10 max-w-2xl">
                  <div className="flex items-center gap-2 text-purple-400 text-sm font-medium mb-1">
                      <Icons.Wand2 className="w-4 h-4" />
                      <span>Full-Stack Analysis Complete</span>
                  </div>
                  <h1 className="text-2xl md:text-3xl font-bold text-white">
                      Webivus has scanned your <code className="bg-white/10 px-1.5 py-0.5 rounded text-purple-200 text-base">api</code> routes and <code className="bg-white/10 px-1.5 py-0.5 rounded text-purple-200 text-base">server actions</code>.
                  </h1>
                  <p className="text-zinc-500">
                      We've identified the stack, indexed 23 components, and detected 3 critical optimization opportunities.
                  </p>
              </div>

              {/* Score Circle */}
              <div className="flex items-center gap-6 bg-[#050505]/50 p-4 pr-8 rounded-2xl border border-white/5 backdrop-blur-sm relative z-10">
                  <div className="relative w-20 h-20 flex items-center justify-center">
                      <svg className="w-full h-full rotate-[-90deg]" viewBox="0 0 36 36">
                          <path className="text-zinc-800" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                          <path className="text-green-500 drop-shadow-[0_0_8px_rgba(34,197,94,0.5)]" strokeDasharray="98, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <span className="text-2xl font-bold text-white">98</span>
                      </div>
                  </div>
                  <div>
                      <div className="text-xs text-zinc-500 uppercase tracking-wider font-bold mb-1">Security Score</div>
                      <div className="text-green-400 text-sm font-medium flex items-center gap-1">
                          <Icons.ShieldCheck className="w-4 h-4" /> Excellent
                      </div>
                  </div>
              </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Left Column: Stack & Structure */}
              <div className="space-y-6">
                  {/* Stack Card */}
                  <div className="bg-[#09090b] border border-white/10 rounded-2xl p-6">
                      <div className="flex items-center justify-between mb-6">
                          <div className="flex items-center gap-2">
                              <Icons.Boxes className="w-5 h-5 text-purple-500" />
                              <h3 className="text-lg font-bold text-white">Detected Stack</h3>
                          </div>
                          <button className="text-xs text-zinc-500 hover:text-white">Edit Config</button>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                          <div className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-[#000] flex items-center justify-center font-bold text-white border border-white/10 text-xl">N</div>
                              <div>
                                  <div className="text-sm font-bold text-white">Next.js</div>
                                  <div className="text-[10px] text-zinc-500">v14.1.0 (App)</div>
                              </div>
                          </div>
                          <div className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500 font-bold border border-blue-500/20">TS</div>
                              <div>
                                  <div className="text-sm font-bold text-white">TypeScript</div>
                                  <div className="text-[10px] text-zinc-500">Strict Mode</div>
                              </div>
                          </div>
                          <div className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20"><Icons.Layout className="w-5 h-5"/></div>
                              <div>
                                  <div className="text-sm font-bold text-white">Tailwind</div>
                                  <div className="text-[10px] text-zinc-500">v3.4.1</div>
                              </div>
                          </div>
                          <div className="p-3 bg-[#0c0c0e] border border-white/5 rounded-xl flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-500 border border-emerald-500/20"><Icons.Database className="w-5 h-5"/></div>
                              <div>
                                  <div className="text-sm font-bold text-white">Prisma</div>
                                  <div className="text-[10px] text-zinc-500">PostgreSQL</div>
                              </div>
                          </div>
                      </div>
                  </div>

                  {/* Project Structure Tree */}
                  <div className="bg-[#09090b] border border-white/10 rounded-2xl p-6 h-[400px] flex flex-col">
                      <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                              <Icons.FolderOpen className="w-5 h-5 text-zinc-400" />
                              <h3 className="text-lg font-bold text-white">Project Structure</h3>
                          </div>
                          <span className="text-xs text-zinc-600">142 Files</span>
                      </div>
                      
                      <div className="flex-1 overflow-y-auto pr-2 space-y-1 font-mono text-sm">
                          {/* Folder: app */}
                          <div>
                              <div className="flex items-center gap-2 py-1 text-zinc-300 hover:bg-white/5 px-2 rounded cursor-pointer">
                                  <Icons.ChevronDown className="w-3 h-3 text-zinc-600" />
                                  <Icons.Folder className="w-3.5 h-3.5 text-blue-500" />
                                  <span>app</span>
                              </div>
                              <div className="pl-6 border-l border-white/5 ml-2.5 space-y-1 mt-1">
                                  <div className="flex items-center gap-2 py-1 text-zinc-400 hover:bg-white/5 px-2 rounded cursor-pointer">
                                      <Icons.ChevronRight className="w-3 h-3 text-zinc-700" />
                                      <Icons.Folder className="w-3.5 h-3.5 text-blue-500/80" />
                                      <span>(auth)</span>
                                  </div>
                                  <div className="flex items-center gap-2 py-1 text-zinc-400 hover:bg-white/5 px-2 rounded cursor-pointer">
                                      <Icons.ChevronRight className="w-3 h-3 text-zinc-700" />
                                      <Icons.Folder className="w-3.5 h-3.5 text-blue-500/80" />
                                      <span>dashboard</span>
                                  </div>
                                  <div className="flex items-center gap-2 py-1 text-purple-300 bg-purple-500/10 px-2 rounded cursor-pointer border border-purple-500/20">
                                      <Icons.ChevronDown className="w-3 h-3" />
                                      <Icons.Folder className="w-3.5 h-3.5 text-purple-400" />
                                      <span>api</span>
                                      <span className="ml-auto text-[10px] bg-purple-500 text-white px-1.5 rounded">Scanned</span>
                                  </div>
                                  <div className="pl-6 border-l border-white/5 ml-2.5 space-y-1 mt-1">
                                      <div className="flex items-center gap-2 py-1 text-zinc-500 hover:bg-white/5 px-2 rounded">
                                          <Icons.FileCode className="w-3.5 h-3.5 text-yellow-500/50" />
                                          <span>layout.tsx</span>
                                      </div>
                                      <div className="flex items-center gap-2 py-1 text-zinc-500 hover:bg-white/5 px-2 rounded">
                                          <Icons.FileCode className="w-3.5 h-3.5 text-blue-500/50" />
                                          <span>page.tsx</span>
                                      </div>
                                      <div className="flex items-center gap-2 py-1 text-zinc-500 hover:bg-white/5 px-2 rounded">
                                          <Icons.FileCode className="w-3.5 h-3.5 text-pink-500/50" />
                                          <span>globals.css</span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          {/* Folder: components */}
                          <div className="flex items-center gap-2 py-1 text-zinc-400 hover:bg-white/5 px-2 rounded cursor-pointer mt-1">
                                  <Icons.ChevronRight className="w-3 h-3 text-zinc-600" />
                                  <Icons.Folder className="w-3.5 h-3.5 text-blue-500" />
                                  <span>components</span>
                          </div>
                          {/* Folder: lib */}
                          <div className="flex items-center gap-2 py-1 text-zinc-400 hover:bg-white/5 px-2 rounded cursor-pointer">
                                  <Icons.ChevronRight className="w-3 h-3 text-zinc-600" />
                                  <Icons.Folder className="w-3.5 h-3.5 text-blue-500" />
                                  <span>lib</span>
                          </div>
                          {/* Folder: prisma */}
                          <div className="flex items-center gap-2 py-1 text-zinc-400 hover:bg-white/5 px-2 rounded cursor-pointer">
                                  <Icons.ChevronRight className="w-3 h-3 text-zinc-600" />
                                  <Icons.Folder className="w-3.5 h-3.5 text-emerald-500" />
                                  <span>prisma</span>
                          </div>
                      </div>
                  </div>
              </div>

              {/* Center & Right Column Combined: Health Audit & Suggestions */}
              <div className="lg:col-span-2 space-y-6">
                  <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                          <Icons.Cpu className="w-5 h-5 text-purple-400" />
                          <h2 className="text-xl font-bold text-white">AI Health Audit</h2>
                      </div>
                      <div className="flex gap-2">
                          <span className="px-2 py-1 rounded bg-red-500/10 text-red-400 text-xs font-bold border border-red-500/20">2 Critical</span>
                          <span className="px-2 py-1 rounded bg-yellow-500/10 text-yellow-400 text-xs font-bold border border-yellow-500/20">3 Warning</span>
                      </div>
                  </div>

                  {/* High Impact Card */}
                  <div className="bg-[#09090b] border border-red-500/30 rounded-2xl p-6 relative overflow-hidden group">
                      <div className="absolute top-0 right-0 p-4">
                           <span className="px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-bold">High Impact</span>
                      </div>
                      
                      <div className="flex gap-4 mb-6">
                          <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center border border-red-500/20 shrink-0">
                              <Icons.AlertCircle className="w-5 h-5 text-red-500" />
                          </div>
                          <div>
                              <h3 className="text-lg font-bold text-white mb-1">Unoptimized Image Loading</h3>
                              <p className="text-zinc-400 text-sm max-w-md">Found 4 images in <code className="text-zinc-300 bg-white/5 px-1 rounded">/landing</code> lacking width/height or priority tags. This affects LCP score.</p>
                          </div>
                      </div>

                      <div className="bg-black/50 rounded-xl border border-white/5 p-4 font-mono text-xs mb-6 relative">
                          <div className="space-y-1">
                              <div className="text-red-400 opacity-60 line-through flex gap-4">
                                  <span className="select-none text-zinc-700">-</span>
                                  <span>{`<img src="/hero.png" />`}</span>
                              </div>
                              <div className="text-green-400 flex gap-4">
                                  <span className="select-none text-zinc-700">+</span>
                                  <span>{`<Image src="/hero.png" width={800} height={600} priority />`}</span>
                              </div>
                          </div>
                      </div>

                      <div className="flex gap-3">
                          <button className="flex-1 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm font-bold transition-all shadow-lg shadow-purple-900/20 flex items-center justify-center gap-2 group-hover:scale-[1.01]">
                              <Icons.Wand2 className="w-4 h-4" /> Apply Fix
                          </button>
                          <button className="px-6 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-sm font-medium transition-colors">
                              Ignore
                          </button>
                      </div>
                  </div>

                  {/* Medium Impact List */}
                  <div className="bg-[#09090b] border border-white/10 rounded-2xl p-6">
                      <div className="space-y-4">
                          
                          {/* Item 1 */}
                          <div className="flex items-start justify-between p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group">
                             <div className="flex gap-4">
                                <div className="w-9 h-9 rounded-lg bg-yellow-500/10 flex items-center justify-center border border-yellow-500/10 shrink-0">
                                   <Icons.Search className="w-4 h-4 text-yellow-500" />
                                </div>
                                <div>
                                   <h4 className="text-sm font-bold text-white mb-0.5">Missing Metadata</h4>
                                   <p className="text-xs text-zinc-500">Dynamic routes in <code className="text-zinc-400">/blog/[slug]</code> are missing <code className="text-zinc-400">generateMetadata</code> function.</p>
                                </div>
                             </div>
                             <div className="flex items-center gap-3">
                                 <span className="px-2 py-0.5 bg-yellow-900/20 text-yellow-500 text-[10px] font-bold rounded border border-yellow-900/30">Medium</span>
                                 <button className="text-xs text-white opacity-0 group-hover:opacity-100 bg-zinc-800 px-3 py-1 rounded transition-opacity">
                                    Generate Code
                                 </button>
                             </div>
                          </div>

                          {/* Item 2 */}
                          <div className="flex items-start justify-between p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group">
                             <div className="flex gap-4">
                                <div className="w-9 h-9 rounded-lg bg-blue-500/10 flex items-center justify-center border border-blue-500/10 shrink-0">
                                   <Icons.MousePointer2 className="w-4 h-4 text-blue-500" />
                                </div>
                                <div>
                                   <h4 className="text-sm font-bold text-white mb-0.5">Button Contrast</h4>
                                   <p className="text-xs text-zinc-500">Low contrast ratio on primary buttons (3.2:1). Recommended 4.5:1.</p>
                                </div>
                             </div>
                             <div className="flex items-center gap-3">
                                 <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-zinc-800 text-zinc-500 hover:text-white transition-colors">
                                     <Icons.ArrowUp className="w-4 h-4 rotate-45" />
                                 </button>
                             </div>
                          </div>

                          {/* Item 3 */}
                          <div className="flex items-start justify-between p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group">
                             <div className="flex gap-4">
                                <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center border border-green-500/10 shrink-0">
                                   <Icons.ShieldCheck className="w-4 h-4 text-green-500" />
                                </div>
                                <div>
                                   <h4 className="text-sm font-bold text-white mb-0.5">Dependency Check</h4>
                                   <p className="text-xs text-zinc-500">All packages are up to date. No vulnerabilities found.</p>
                                </div>
                             </div>
                             <div className="flex items-center gap-3">
                                 <Icons.CheckCircle2 className="w-5 h-5 text-green-500" />
                             </div>
                          </div>

                      </div>
                  </div>
              </div>
          </div>
          
          {/* Footer Tip */}
          <div className="mt-8 border-t border-dashed border-white/10 pt-4 flex items-center justify-between text-xs text-zinc-500">
              <div className="flex items-center gap-2">
                 <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                 <span>Tip: Use <strong className="text-zinc-300">CMD + K</strong> to open the command palette for quick fixes.</span>
              </div>
              <span>Last scan: 2 minutes ago</span>
          </div>

      </main>
    </div>
  );
};

export default SummaryScreen;
