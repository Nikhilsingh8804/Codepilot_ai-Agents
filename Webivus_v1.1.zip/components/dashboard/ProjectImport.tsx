
import React, { useState, useEffect } from 'react';
import { Icons } from '../ui/Icons';
import { ImportMethod, Project, User } from '../../types';
import { getUserRepos, fetchRepoFiles, getGithubInstallations, installGithubApp, GithubInstallation } from '../../services/githubService';

interface ProjectImportProps {
  user: User;
  onProjectSelect: (project: Project) => void;
  onBack: () => void;
}

const ProjectImport: React.FC<ProjectImportProps> = ({ user, onProjectSelect, onBack }) => {
  const [selectedMethod, setSelectedMethod] = useState<ImportMethod | null>(null);
  
  // GitHub Specific State
  const [installations, setInstallations] = useState<GithubInstallation[]>([]);
  const [selectedInstallation, setSelectedInstallation] = useState<GithubInstallation | null>(null);
  const [repos, setRepos] = useState<any[]>([]);
  const [isLoadingRepos, setIsLoadingRepos] = useState(false);
  const [isInstallingApp, setIsInstallingApp] = useState(false);
  
  const [isImporting, setIsImporting] = useState<number | null>(null); 
  const [searchTerm, setSearchTerm] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleMethodSelect = async (method: ImportMethod) => {
    setSelectedMethod(method);
    if (method === 'github') {
      setIsLoadingRepos(true);
      try {
        // 1. Check for existing installations (Personal or Org)
        const installs = await getGithubInstallations();
        setInstallations(installs);
        
        if (installs.length > 0) {
            setSelectedInstallation(installs[0]); // Default to first (usually personal)
            const data = await getUserRepos();
            setRepos(data);
        } else {
            // No installations found, UI will show "Install App" state
            setRepos([]);
        }
      } catch (err) {
        console.error("Failed to load github data", err);
      } finally {
        setIsLoadingRepos(false);
      }
    }
  };

  const handleInstallApp = async () => {
      setIsInstallingApp(true);
      try {
          await installGithubApp();
          // After simulated install, refresh list
          const installs = await getGithubInstallations();
          // Mock adding one if the service returned empty
          if (installs.length === 0) {
              const newInstall = { id: 123, account: { login: user.name || 'webivus-user', avatar_url: user.avatarUrl || '', type: 'User' } };
              setInstallations([newInstall]);
              setSelectedInstallation(newInstall);
          } else {
              setInstallations(installs);
              setSelectedInstallation(installs[0]);
          }
          const data = await getUserRepos();
          setRepos(data);
      } catch (e) {
          console.error("Install failed", e);
      } finally {
          setIsInstallingApp(false);
      }
  };

  const handleRepoSelect = async (repo: any) => {
    setIsImporting(repo.id);
    
    // Fetch real files
    let fetchedFiles: Record<string, string> = {};
    try {
        if (repo.owner && repo.name) {
             fetchedFiles = await fetchRepoFiles(repo.owner.login, repo.name);
        } else if (repo.full_name) {
             const [owner, name] = repo.full_name.split('/');
             fetchedFiles = await fetchRepoFiles(owner, name);
        }
    } catch (e) {
        console.error("Error fetching files, continuing with empty project", e);
    }
    
    const isSimulatedRepo = repo.id === 999;
    const finalFiles = isSimulatedRepo ? undefined : fetchedFiles;

    onProjectSelect({
      id: repo.id.toString(),
      name: repo.name,
      description: repo.description,
      repoUrl: repo.full_name,
      branch: repo.default_branch || 'main',
      lastUpdated: new Date().toISOString(),
      framework: 'Next.js', 
      files: finalFiles
    });
    
    setIsImporting(null);
  };

  // Helper to get time ago string
  const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return Math.floor(seconds) + "s ago";
  };

  // Helper to determine language color
  const getLangColor = (lang?: string) => {
      if (!lang) return 'bg-zinc-500';
      const l = lang.toLowerCase();
      if (l === 'typescript') return 'bg-blue-500';
      if (l === 'javascript') return 'bg-yellow-400';
      if (l === 'python') return 'bg-green-500';
      if (l === 'html') return 'bg-orange-500';
      if (l === 'css') return 'bg-pink-500';
      return 'bg-zinc-500';
  };

  // Helper to get framework icon
  const getFrameworkIcon = (name: string, lang?: string) => {
     const n = name.toLowerCase();
     if (n.includes('next')) return <div className="font-extrabold text-[10px] tracking-tighter text-white">NEXT</div>;
     if (n.includes('react')) return <Icons.Cpu className="w-5 h-5 text-cyan-400" />;
     if (lang?.toLowerCase() === 'python') return <Icons.Terminal className="w-5 h-5 text-yellow-400" />;
     return <Icons.Code2 className="w-5 h-5 text-white" />;
  };

  const methods = [
    {
      id: 'github',
      name: 'GitHub',
      icon: Icons.Github,
      description: 'Import directly from your GitHub repositories.',
      color: 'from-zinc-800 to-black',
      textColor: 'text-white'
    },
    {
      id: 'vercel',
      name: 'Vercel',
      icon: Icons.Layout,
      description: 'Import projects from your Vercel deployments.',
      color: 'from-black to-zinc-900',
      textColor: 'text-white'
    },
    {
      id: 'netlify',
      name: 'Netlify',
      icon: Icons.Cloud, 
      description: 'Import from your Netlify sites.',
      color: 'from-cyan-900/50 to-cyan-950/30',
      textColor: 'text-cyan-400'
    },
    {
      id: 'upload',
      name: 'Upload',
      icon: Icons.Upload,
      description: 'Drag and drop your project ZIP file.',
      color: 'from-indigo-900/50 to-indigo-950/30',
      textColor: 'text-indigo-400'
    }
  ];

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col text-zinc-400 font-sans selection:bg-purple-500/30">
      
      {/* --- HEADER --- */}
      <header className="h-20 border-b border-white/10 bg-[#09090b]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between px-6 md:px-10 shrink-0">
         <div className="flex items-center gap-6">
            <button 
              onClick={onBack}
              className="group flex items-center gap-2 text-sm font-medium text-zinc-500 hover:text-white transition-colors"
            >
               <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center bg-white/5 group-hover:bg-white/10 transition-colors">
                  <Icons.ChevronRight className="w-4 h-4 rotate-180" />
               </div>
               Back
            </button>
            <div className="h-6 w-px bg-white/10 hidden md:block" />
            <h1 className="text-lg font-bold text-white hidden md:block">Create New Project</h1>
         </div>

         <div className="flex items-center gap-4">
             <div className="text-right hidden md:block">
                 <div className="text-sm font-bold text-white">{user.name}</div>
                 <div className="text-xs text-zinc-500">{user.email}</div>
             </div>
             <img src={user.avatarUrl} alt="User" className="w-10 h-10 rounded-full border border-white/10 bg-zinc-800" />
         </div>
      </header>

      {/* --- CONTENT --- */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-6 md:p-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          {!selectedMethod ? (
             <div className="space-y-10">
                <div className="text-center space-y-3">
                   <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">Let's build something new.</h2>
                   <p className="text-lg text-zinc-500 max-w-xl mx-auto">
                     Select a source to import your project from. Webivus will analyze the code and prepare your workspace.
                   </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   {methods.map((method) => (
                      <button
                        key={method.id}
                        onClick={() => handleMethodSelect(method.id as ImportMethod)}
                        className="group relative h-48 rounded-3xl border border-white/10 bg-[#09090b] hover:border-purple-500/50 transition-all overflow-hidden text-left p-8 flex flex-col justify-between hover:shadow-2xl hover:shadow-purple-900/10"
                      >
                         <div className={`absolute inset-0 bg-gradient-to-br ${method.color} opacity-0 group-hover:opacity-10 transition-opacity`} />
                         
                         <div className="flex justify-between items-start">
                            <div className={`w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center ${method.textColor} group-hover:scale-110 transition-transform`}>
                               <method.icon className="w-7 h-7" />
                            </div>
                            <div className="opacity-0 group-hover:opacity-100 transition-opacity -mr-2 -mt-2">
                               <Icons.ChevronRight className="w-5 h-5 text-zinc-500" />
                            </div>
                         </div>
                         
                         <div className="relative z-10">
                            <h3 className="text-xl font-bold text-white mb-1 group-hover:translate-x-1 transition-transform">{method.name}</h3>
                            <p className="text-sm text-zinc-500 group-hover:translate-x-1 transition-transform delay-75">{method.description}</p>
                         </div>
                      </button>
                   ))}
                </div>
             </div>
          ) : (
            <div className="space-y-6">
                <button 
                  onClick={() => setSelectedMethod(null)}
                  className="flex items-center gap-2 text-sm text-zinc-500 hover:text-white transition-colors mb-4"
                >
                  <Icons.ChevronRight className="w-4 h-4 rotate-180" /> Change Source
                </button>

                {selectedMethod === 'github' && (
                  <div className="bg-[#09090b] border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[750px]">
                    
                    {/* Header Section (Account Scope + Search) */}
                    <div className="p-8 border-b border-white/10 bg-[#0c0c0e]">
                        
                        {/* Scope Selector */}
                        <div className="flex items-start gap-4 mb-8">
                             {/* Large Icon Box */}
                             <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white shrink-0">
                                <Icons.Github className="w-7 h-7" />
                             </div>
                             
                             {/* Dropdown Trigger */}
                             <div className="relative">
                                <button 
                                  onClick={() => setDropdownOpen(!dropdownOpen)}
                                  className="group flex items-center gap-2 text-xl font-bold text-white hover:opacity-90 transition-opacity text-left"
                                >
                                   {selectedInstallation ? selectedInstallation.account.login : 'Select Account'}
                                   <Icons.ChevronDown className={`w-5 h-5 text-zinc-500 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                                </button>
                                <div className="text-sm text-zinc-500 mt-0.5">Import Git Repository</div>

                                {/* Dropdown Menu */}
                                {dropdownOpen && (
                                    <div className="absolute top-full left-0 mt-3 w-72 bg-[#18181b] border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200 ring-1 ring-black/50">
                                        <div className="p-3 bg-zinc-900/50 border-b border-white/5 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                                            Switch Scope
                                        </div>
                                        {installations.map(inst => (
                                            <button 
                                              key={inst.id}
                                              onClick={() => { setSelectedInstallation(inst); setDropdownOpen(false); }}
                                              className="w-full flex items-center gap-3 p-3 hover:bg-white/5 transition-colors text-left border-b border-white/5 last:border-0"
                                            >
                                                <img src={inst.account.avatar_url} className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10" alt="" />
                                                <div className="flex-1 min-w-0">
                                                   <div className="text-sm text-white font-medium truncate">{inst.account.login}</div>
                                                   <div className="text-xs text-zinc-500 capitalize">{inst.account.type}</div>
                                                </div>
                                                {inst.id === selectedInstallation?.id && <Icons.CheckCircle2 className="w-4 h-4 text-purple-500 ml-auto" />}
                                            </button>
                                        ))}
                                        <button 
                                            onClick={() => { handleInstallApp(); setDropdownOpen(false); }}
                                            className="w-full flex items-center gap-3 p-3 text-sm text-zinc-400 hover:text-white hover:bg-white/5 transition-colors bg-zinc-900/30"
                                        >
                                            <div className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center bg-white/5"><Icons.Plus className="w-4 h-4" /></div>
                                            Add GitHub Organization...
                                        </button>
                                    </div>
                                )}
                             </div>
                        </div>

                        {/* Search Bar - Integrated into Header */}
                        {installations.length > 0 && (
                          <div className="relative group">
                            <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500 group-focus-within:text-white transition-colors" />
                            <input 
                              type="text" 
                              placeholder="Search repositories..."
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                              className="w-full pl-11 pr-4 py-3.5 bg-black border border-white/10 rounded-xl focus:outline-none focus:ring-1 focus:ring-purple-500/50 focus:border-purple-500/50 text-white placeholder:text-zinc-600 transition-all text-sm font-medium shadow-inner"
                              autoFocus
                            />
                          </div>
                        )}
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3 relative bg-[#050505] scrollbar-thin scrollbar-thumb-zinc-800">
                       {isLoadingRepos ? (
                          <div className="flex flex-col items-center justify-center h-full text-zinc-500 space-y-3">
                             <Icons.Loader2 className="w-8 h-8 animate-spin text-purple-500" />
                             <p className="text-sm">Fetching your repositories...</p>
                          </div>
                       ) : installations.length === 0 ? (
                           /* --- EMPTY STATE: NO APP INSTALLED --- */
                           <div className="flex flex-col items-center justify-center h-full text-center p-8">
                               <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-6 border border-white/10">
                                   <Icons.Github className="w-8 h-8 text-white" />
                               </div>
                               <h3 className="text-xl font-bold text-white mb-2">Install Webivus AI Code</h3>
                               <p className="text-zinc-500 max-w-sm mb-8 text-sm leading-relaxed">
                                   Webivus needs access to your repositories to analyze code and generate PRs. Install the GitHub App to proceed.
                               </p>
                               <button 
                                 onClick={handleInstallApp}
                                 disabled={isInstallingApp}
                                 className="px-6 py-3 bg-white text-black hover:bg-zinc-200 rounded-full font-bold transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] flex items-center gap-2"
                               >
                                  {isInstallingApp ? <Icons.Loader2 className="w-4 h-4 animate-spin"/> : <Icons.Github className="w-4 h-4" />}
                                  {isInstallingApp ? 'Installing...' : 'Install GitHub App'}
                               </button>
                           </div>
                       ) : (
                          /* --- ADVANCED REPO LIST --- */
                          <>
                             {repos.filter(r => r.name.toLowerCase().includes(searchTerm.toLowerCase())).map((repo) => (
                                <div 
                                  key={repo.id} 
                                  className="group bg-[#09090b] border border-white/5 rounded-xl p-5 hover:border-purple-500/30 transition-all cursor-pointer relative overflow-hidden"
                                  onClick={() => handleRepoSelect(repo)}
                                >
                                   {/* Import Button (Absolute Positioned) */}
                                   <div className="absolute right-5 top-5 z-10 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-4 group-hover:translate-x-0">
                                       <button 
                                         disabled={isImporting !== null}
                                         className={`
                                            px-5 py-2 rounded-lg text-sm font-bold shadow-lg flex items-center gap-2
                                            ${isImporting === repo.id ? 'bg-zinc-800 text-zinc-400' : 'bg-white text-black hover:bg-zinc-200'}
                                         `}
                                       >
                                          {isImporting === repo.id ? <Icons.Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                                          {isImporting === repo.id ? 'Importing' : 'Import'}
                                       </button>
                                   </div>

                                   <div className="flex gap-5">
                                      {/* Icon/Logo */}
                                      <div className="w-12 h-12 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-white shadow-inner">
                                          {getFrameworkIcon(repo.name, repo.language)}
                                      </div>

                                      {/* Info */}
                                      <div className="flex-1 min-w-0 pt-0.5">
                                         <div className="flex items-center gap-3 mb-1.5">
                                            <h3 className="text-base font-bold text-white truncate group-hover:text-purple-400 transition-colors">{repo.name}</h3>
                                            <span className={`text-[10px] px-2 py-0.5 rounded-full border ${repo.private ? 'bg-zinc-900 border-zinc-800 text-zinc-400' : 'bg-blue-900/10 border-blue-900/20 text-blue-400'} font-medium`}>
                                               {repo.private ? 'Private' : 'Public'}
                                            </span>
                                         </div>

                                         {/* Simulated Commit Message */}
                                         <div className="flex items-start gap-2 text-sm text-zinc-400 mb-5 pr-24">
                                            <span className="truncate line-clamp-1">{repo.description || `Update ${repo.default_branch || 'main'} with latest changes`}</span>
                                         </div>

                                         {/* Meta Footer */}
                                         <div className="flex items-center gap-4 text-xs text-zinc-500 font-medium">
                                            <div className="flex items-center gap-1.5">
                                               <div className={`w-2 h-2 rounded-full ${getLangColor(repo.language)}`} />
                                               {repo.language || 'Unknown'}
                                            </div>
                                            {repo.stargazers_count > 0 && (
                                                <div className="flex items-center gap-1.5">
                                                   <svg className="w-3 h-3 mb-0.5" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                                                   {repo.stargazers_count}
                                                </div>
                                            )}
                                            <div className="flex items-center gap-1">
                                                <span>{timeAgo(repo.updated_at)}</span>
                                            </div>
                                            <div className="flex items-center gap-1 font-mono text-[10px] bg-white/5 px-1.5 py-0.5 rounded text-zinc-400">
                                                {repo.default_branch || 'main'}
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                             ))}
                             
                             {/* Empty search result within installed app */}
                             {repos.length > 0 && repos.filter(r => r.name.toLowerCase().includes(searchTerm.toLowerCase())).length === 0 && (
                                <div className="flex flex-col items-center justify-center py-12 text-zinc-500">
                                   <p className="mb-2">No repositories found matching "{searchTerm}".</p>
                                   <p className="text-xs">
                                      Missing a repo? <button onClick={handleInstallApp} className="text-blue-400 hover:underline">Adjust GitHub App Permissions</button>
                                   </p>
                                </div>
                             )}
                          </>
                       )}
                    </div>
                    
                    {/* Footer: Permission Adjustment Link */}
                    {installations.length > 0 && (
                        <div className="p-4 bg-[#09090b] border-t border-white/5 text-center">
                            <button 
                                onClick={handleInstallApp}
                                className="text-xs text-zinc-500 hover:text-blue-400 transition-colors flex items-center justify-center gap-1 mx-auto"
                            >
                                Missing Git repository? <span className="text-blue-500 font-medium">Adjust GitHub App Permissions →</span>
                            </button>
                        </div>
                    )}
                  </div>
                )}

                {selectedMethod !== 'github' && (
                  <div className="bg-[#09090b] border border-white/10 rounded-2xl p-10 text-center flex flex-col items-center justify-center min-h-[400px]">
                     <div className="w-20 h-20 bg-[#050505] border border-white/10 rounded-full flex items-center justify-center mb-6 shadow-inner">
                       <Icons.Code2 className="w-8 h-8 text-zinc-600" />
                     </div>
                     <h3 className="text-2xl font-bold text-white mb-2">Simulated Import</h3>
                     <p className="text-zinc-500 max-w-sm mb-8">
                        This method is simulated for the demo. You can proceed with a demo project structure to explore the interface.
                     </p>
                     <button 
                        onClick={() => handleRepoSelect({ id: 999, name: "demo-project-zip", description: "Uploaded project", full_name: "local/demo", branch: "main", updated_at: new Date().toISOString() })}
                        className="px-8 py-3 bg-white text-black hover:bg-zinc-200 rounded-full font-bold transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:scale-105"
                      >
                        Create Demo Project
                     </button>
                  </div>
                )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ProjectImport;
