
import React, { useEffect, useState } from 'react';
import { Icons } from '../ui/Icons';
import { User } from '../../types';

interface LandingPageProps {
   onGetStarted: () => void;
   user: User | null;
   onLogout: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, user, onLogout }) => {
   const [scrolled, setScrolled] = useState(false);
   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

   useEffect(() => {
      const handleScroll = () => setScrolled(window.scrollY > 20);
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
   }, []);

   return (
      <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-purple-500/30 flex flex-col overflow-x-hidden">
         
         {/* --- STICKY HEADER --- */}
         <nav 
            className={`
               fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b
               ${scrolled ? 'bg-[#050505]/80 backdrop-blur-xl border-white/5 py-4' : 'bg-transparent border-transparent py-6'}
            `}
         >
            <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
               {/* Logo */}
               <div 
                  className="flex items-center gap-2.5 font-bold text-xl tracking-tight cursor-pointer group" 
                  onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
               >
                  <div className="relative flex items-center">
                      <div className="absolute inset-0 bg-purple-500/50 blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      <img src="/logos.svg" alt="" className="h-8 w-auto relative z-10 block" />
                  </div>
                  <span className="text-white">Webivus</span>
               </div>
               
               {/* Desktop Nav */}
               <div className="hidden md:flex items-center gap-8">
                  {[
                     { name: 'Features', href: '#features' },
                     { name: 'Solutions', href: '#solutions' },
                     { name: 'Pricing', href: '#pricing' },
                  ].map((item) => (
                     <a 
                        key={item.name} 
                        href={item.href} 
                        className="text-sm font-medium text-zinc-400 hover:text-white transition-colors relative group"
                     >
                        {item.name}
                        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-purple-500 transition-all group-hover:w-full" />
                     </a>
                  ))}
               </div>

               {/* CTA Buttons */}
               <div className="hidden md:flex items-center gap-4">
                  {user ? (
                     <button
                        onClick={onGetStarted}
                        className="px-5 py-2.5 bg-white text-black text-sm font-bold rounded-full transition-all hover:bg-zinc-200 hover:scale-105 active:scale-95 flex items-center gap-2"
                     >
                        Workspace <Icons.ArrowUp className="w-4 h-4 rotate-45" />
                     </button>
                  ) : (
                     <>
                        <button
                           onClick={onGetStarted}
                           className="group px-5 py-2.5 bg-white text-black text-sm font-bold rounded-full transition-all hover:bg-zinc-200 hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                        >
                           Start Building Free
                        </button>
                     </>
                  )}
               </div>

               {/* Mobile Menu Toggle */}
               <button 
                  className="md:hidden text-zinc-300 hover:text-white"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
               >
                  {mobileMenuOpen ? <Icons.X className="w-6 h-6" /> : <Icons.Menu className="w-6 h-6" />}
               </button>
            </div>

            {/* Mobile Menu Overlay */}
            {mobileMenuOpen && (
               <div className="md:hidden absolute top-full left-0 w-full bg-[#050505] border-b border-white/10 p-6 flex flex-col gap-4 animate-in slide-in-from-top-4 shadow-2xl">
                   <a href="#features" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-zinc-300">Features</a>
                   <a href="#solutions" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-zinc-300">Solutions</a>
                   <a href="#pricing" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-zinc-300">Pricing</a>
                   <div className="h-px bg-white/10 my-2" />
                   <button onClick={onGetStarted} className="w-full py-3 bg-white text-black font-bold rounded-xl">Start Building</button>
               </div>
            )}
         </nav>

         <main className="flex-1">
            
            {/* --- HERO SECTION --- */}
            <section className="relative pt-32 pb-24 md:pt-48 md:pb-32 px-6 overflow-hidden">
               <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1400px] h-[600px] bg-purple-900/10 rounded-[100%] blur-[120px] pointer-events-none opacity-40" />
               
               <div className="max-w-4xl mx-auto text-center relative z-10">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-purple-300 backdrop-blur-md mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                     <Icons.Sparkles className="w-3.5 h-3.5 text-purple-400" />
                     <span className="tracking-wide">AI-Native Engineering for Founders</span>
                  </div>

                  <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[1.05] mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-white/50 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
                     Turn ideas into <br /> production apps.
                  </h1>

                  <p className="text-lg md:text-xl text-zinc-400 max-w-2xl mx-auto leading-relaxed mb-10 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
                     Webivus acts as your AI Co-Founder. Connect your GitHub, describe your feature, and let our agents architect, code, and deploy your full-stack application.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300">
                     <button
                        onClick={onGetStarted}
                        className="h-14 px-10 bg-white text-black hover:bg-zinc-200 rounded-full font-bold text-lg transition-all shadow-[0_0_40px_rgba(255,255,255,0.2)] hover:scale-105 active:scale-95"
                     >
                        Start Building Free
                     </button>
                     <button className="h-14 px-10 border border-white/10 hover:bg-white/5 rounded-full font-medium text-lg text-zinc-300 hover:text-white transition-colors flex items-center justify-center gap-2">
                        <Icons.PlayCircle className="w-5 h-5" /> View Demo
                     </button>
                  </div>
               </div>
            </section>

            {/* --- INTEGRATIONS STRIP --- */}
            <section className="py-12 border-y border-white/5 bg-black/50">
               <div className="max-w-7xl mx-auto px-6 text-center">
                  <p className="text-xs font-bold text-zinc-600 uppercase tracking-widest mb-8">Connects with everything you use</p>
                  <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-70 grayscale hover:grayscale-0 transition-all duration-500">
                     <div className="flex items-center gap-2 text-xl font-bold text-white"><Icons.Github className="w-6 h-6" /> GitHub</div>
                     <div className="flex items-center gap-2 text-xl font-bold text-white"><Icons.Gitlab className="w-6 h-6 text-orange-500" /> GitLab</div>
                     <div className="flex items-center gap-2 text-xl font-bold text-white"><Icons.GitBranch className="w-6 h-6 text-blue-500" /> Bitbucket</div>
                     <div className="h-8 w-px bg-white/10 hidden md:block"></div>
                     <div className="flex items-center gap-2 text-xl font-bold text-white"><Icons.Triangle className="w-6 h-6 text-white fill-white" /> Vercel</div>
                     <div className="flex items-center gap-2 text-xl font-bold text-white"><Icons.Cloud className="w-6 h-6 text-cyan-400 fill-cyan-400" /> Netlify</div>
                  </div>
               </div>
            </section>

            {/* --- REVERSE ENGINEERING FEATURE --- */}
            <section id="solutions" className="py-32 bg-[#050505] relative overflow-hidden">
                <div className="absolute top-1/2 right-0 w-[800px] h-[600px] bg-purple-900/10 rounded-full blur-[120px] pointer-events-none -translate-y-1/2 translate-x-1/2" />
                
                <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center relative z-10">
                    <div>
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-bold text-blue-400 mb-6">
                           <Icons.Globe className="w-3.5 h-3.5" /> Hosting Integration
                        </div>
                        <h2 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                           Lost your developer?<br />
                           <span className="text-zinc-500">Don't lose your code.</span>
                        </h2>
                        <p className="text-lg text-zinc-400 mb-8 leading-relaxed">
                           It happens. Developers move on, repositories get lost. Webivus connects directly to your hosting providers like <strong>Vercel</strong> and <strong>Netlify</strong> to retrieve your latest build.
                        </p>
                        
                        <ul className="space-y-4 mb-10">
                           <li className="flex items-center gap-3 text-zinc-300">
                              <Icons.CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0" />
                              Reverse-engineer deployment builds back to source code.
                           </li>
                           <li className="flex items-center gap-3 text-zinc-300">
                              <Icons.CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0" />
                              Auto-detect Next.js, React, and Vue frameworks.
                           </li>
                           <li className="flex items-center gap-3 text-zinc-300">
                              <Icons.CheckCircle2 className="w-5 h-5 text-blue-500 shrink-0" />
                              Re-establish a new Git repository in your own account.
                           </li>
                        </ul>

                        <button onClick={onGetStarted} className="text-white font-bold border-b border-white hover:text-purple-400 hover:border-purple-400 transition-colors pb-0.5 inline-flex items-center gap-2 group">
                           Import from URL <Icons.ArrowDown className="w-4 h-4 -rotate-90 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </div>

                    {/* Visual Card */}
                    <div className="bg-[#09090b] border border-white/10 rounded-2xl p-8 shadow-2xl relative animate-in fade-in slide-in-from-right-8 duration-700">
                        <div className="flex items-center justify-between mb-8 pb-8 border-b border-white/5">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-lg bg-black flex items-center justify-center border border-white/10">
                                   <Icons.Triangle className="w-6 h-6 text-white fill-white" />
                                </div>
                                <div>
                                   <div className="text-white font-bold">acme-corp-site</div>
                                   <div className="text-xs text-zinc-500">Vercel Deployment • Production</div>
                                </div>
                            </div>
                            <span className="px-2 py-1 bg-green-500/10 text-green-500 text-xs font-bold rounded border border-green-500/20">Active</span>
                        </div>

                        <div className="space-y-6 font-mono text-sm">
                            <div className="flex items-center gap-3 text-zinc-500">
                                <Icons.Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                                <span>Fetching deployment bundle...</span>
                            </div>
                            <div className="flex items-center gap-3 text-white">
                                <Icons.CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>Detected Framework: <span className="text-white font-bold">Next.js 14 (App Router)</span></span>
                            </div>
                            <div className="flex items-center gap-3 text-white">
                                <Icons.CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>Reconstructing src/app/page.tsx</span>
                            </div>
                            <div className="flex items-center gap-3 text-white">
                                <Icons.CheckCircle2 className="w-4 h-4 text-green-500" />
                                <span>Reconstructing tailwind.config.ts</span>
                            </div>
                        </div>

                        <div className="mt-8 bg-[#0c0c0e] rounded-xl border border-white/5 p-4 flex items-center justify-between group cursor-pointer hover:border-white/10 transition-colors">
                            <div className="flex items-center gap-3">
                                <Icons.Github className="w-5 h-5 text-white" />
                                <div>
                                   <div className="text-xs text-zinc-500 mb-0.5">Destination</div>
                                   <div className="text-sm font-bold text-white">github.com/you/acme-recovered</div>
                                </div>
                            </div>
                            <Icons.ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-white transition-colors" />
                        </div>
                    </div>
                </div>
            </section>

            {/* --- SELF HEALING FEATURE --- */}
            <section id="features" className="py-24 bg-[#08080a]">
               <div className="max-w-7xl mx-auto px-6">
                  {/* Large Card Container */}
                  <div className="bg-[#09090b] border border-white/10 rounded-[2.5rem] p-10 md:p-16 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-16 group hover:border-purple-500/20 transition-all duration-500">
                     
                     {/* Text Side */}
                     <div className="max-w-xl relative z-10">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-xs font-bold text-green-400 mb-8">
                           <Icons.ShieldCheck className="w-3.5 h-3.5" /> Self-Healing Codebase
                        </div>
                        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                           It fixes bugs while you sleep.
                        </h2>
                        <p className="text-lg text-zinc-400 leading-relaxed">
                           Our QA Agents constantly scan your project for hydration errors, memory leaks, and accessibility issues. When a bug is found, Webivus automatically writes a fix and opens a Pull Request.
                        </p>
                     </div>

                     {/* Visual Side (Terminal) */}
                     <div className="w-full md:w-[480px] shrink-0 relative z-10">
                        <div className="bg-[#050505] rounded-2xl border border-white/10 shadow-2xl overflow-hidden font-mono text-xs">
                           {/* Terminal Header */}
                           <div className="bg-[#0c0c0e] px-4 py-3 border-b border-white/5 flex items-center justify-between">
                              <div className="flex gap-1.5">
                                 <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50" />
                                 <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
                                 <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50" />
                              </div>
                              <div className="text-zinc-500">webivus-qa-agent</div>
                           </div>
                           
                           {/* Terminal Body */}
                           <div className="p-6 space-y-6">
                              {/* Error */}
                              <div className="flex gap-4">
                                 <div className="text-red-500 flex-col flex items-center pt-1">
                                    <Icons.AlertTriangle className="w-4 h-4" />
                                 </div>
                                 <div className="space-y-1">
                                    <div className="text-red-400 font-bold">1 Error Detected</div>
                                    <div className="text-zinc-600">src/app/page.tsx</div>
                                 </div>
                              </div>

                              {/* Code Block */}
                              <div className="bg-[#0c0c0e] p-4 rounded-lg border border-white/5 relative group-hover:border-white/10 transition-colors">
                                 <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Icons.Code2 className="w-4 h-4 text-zinc-600" />
                                 </div>
                                 <div className="space-y-1 text-zinc-400">
                                    <div className="opacity-50 line-through decoration-red-500/50 text-red-400/70">
                                       {'<div>{new Date().toLocaleTimeString()}</div>'}
                                    </div>
                                    <div className="flex justify-center py-2">
                                       <Icons.ArrowDown className="w-4 h-4 text-zinc-700" />
                                    </div>
                                    <div className="text-green-400">
                                       {'const [mounted, setMounted] = useState(false);'}
                                    </div>
                                    <div className="text-green-400">
                                       {'if (!mounted) return null;'}
                                    </div>
                                    <div className="text-green-400">
                                       {'<div>{new Date().toLocaleTimeString()}</div>'}
                                    </div>
                                 </div>
                              </div>

                              {/* Status */}
                              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                                 <div className="flex items-center gap-2 text-zinc-500">
                                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                                    <span>Fix applied</span>
                                 </div>
                                 <div className="text-purple-400">PR #402 Created</div>
                              </div>
                           </div>
                        </div>
                     </div>

                     {/* Background Glow */}
                     <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/5 blur-[100px] rounded-full pointer-events-none" />
                  </div>
               </div>
            </section>

            {/* --- ARCHITECT CARD --- */}
            <section className="pb-32 px-6">
               <div className="max-w-7xl mx-auto">
                  <div className="grid md:grid-cols-2 gap-6">
                     <div className="bg-[#09090b] border border-white/10 rounded-3xl p-8 md:p-12 relative overflow-hidden group hover:border-white/20 transition-all">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[80px] rounded-full pointer-events-none" />
                        <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20 mb-6">
                           <Icons.Boxes className="w-6 h-6 text-blue-400" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">The Architect</h3>
                        <p className="text-zinc-400 mb-8 leading-relaxed">Describe your app in plain English. We generate the folder structure, database schema, and API routes automatically.</p>
                        <div className="font-mono text-xs text-zinc-500 bg-black/50 p-4 rounded-xl border border-white/5">
                           > Generating schema.prisma...<br/>
                           > Creating /app/dashboard/layout.tsx...
                        </div>
                     </div>

                     <div className="bg-[#09090b] border border-white/10 rounded-3xl p-8 md:p-12 relative overflow-hidden group hover:border-white/20 transition-all">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 blur-[80px] rounded-full pointer-events-none" />
                        <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center border border-orange-500/20 mb-6">
                           <Icons.GitBranch className="w-6 h-6 text-orange-400" />
                        </div>
                        <h3 className="text-2xl font-bold text-white mb-2">Native Git Sync</h3>
                        <p className="text-zinc-400 mb-8 leading-relaxed">We don't lock you in. Webivus pushes real commits to your own GitHub repo, keeping your history clean and portable.</p>
                        <div className="flex items-center gap-2 text-sm text-zinc-300">
                           <Icons.CheckCircle2 className="w-4 h-4 text-orange-500" /> Pull Requests
                           <Icons.CheckCircle2 className="w-4 h-4 text-orange-500 ml-4" /> Code Reviews
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            {/* --- CTA SECTION --- */}
            <section className="py-32 relative overflow-hidden border-t border-white/5">
               <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
                  <h2 className="text-5xl md:text-7xl font-bold tracking-tight mb-8">
                     Ready to ship faster?
                  </h2>
                  <p className="text-xl text-zinc-400 mb-12 max-w-2xl mx-auto">
                     Your AI Co-Founder is waiting. Join thousands of developers reclaiming their time with Webivus.
                  </p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                     <button
                        onClick={onGetStarted}
                        className="h-16 px-12 bg-white text-black hover:bg-zinc-200 rounded-full font-bold text-xl transition-all shadow-[0_0_40px_rgba(255,255,255,0.3)] hover:scale-105"
                     >
                        Start Building Free
                     </button>
                  </div>
                  <p className="mt-6 text-sm text-zinc-500">No credit card required • Free during beta</p>
               </div>
            </section>
         </main>

         {/* --- PROFESSIONAL FOOTER --- */}
         <footer className="py-16 px-6 border-t border-white/5 bg-[#050505] text-sm">
            <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-10">
               <div className="col-span-2 lg:col-span-2">
                   <div className="flex items-center gap-2 font-bold text-xl text-white mb-6">
                      <img src="/logos.svg" alt="" className="h-8 w-auto" /> Webivus
                   </div>
                   <p className="text-zinc-500 mb-6 max-w-xs leading-relaxed">
                      The AI-native development platform that acts as your technical co-founder. Architect, code, and deploy in minutes.
                   </p>
                   <div className="flex gap-4">
                      <Icons.Github className="w-5 h-5 text-zinc-600 hover:text-white cursor-pointer transition-colors" />
                      <Icons.Twitter className="w-5 h-5 text-zinc-600 hover:text-white cursor-pointer transition-colors" />
                      <Icons.Linkedin className="w-5 h-5 text-zinc-600 hover:text-white cursor-pointer transition-colors" />
                   </div>
               </div>
               
               <div>
                  <h4 className="font-bold text-white mb-6">Product</h4>
                  <ul className="space-y-4 text-zinc-500">
                     <li className="hover:text-white cursor-pointer transition-colors">Features</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Integrations</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Pricing</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Changelog</li>
                  </ul>
               </div>

               <div>
                  <h4 className="font-bold text-white mb-6">Resources</h4>
                  <ul className="space-y-4 text-zinc-500">
                     <li className="hover:text-white cursor-pointer transition-colors">Documentation</li>
                     <li className="hover:text-white cursor-pointer transition-colors">API Reference</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Community</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Blog</li>
                  </ul>
               </div>

               <div>
                  <h4 className="font-bold text-white mb-6">Company</h4>
                  <ul className="space-y-4 text-zinc-500">
                     <li className="hover:text-white cursor-pointer transition-colors">About</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Careers</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Contact</li>
                     <li className="hover:text-white cursor-pointer transition-colors">Privacy</li>
                  </ul>
               </div>
            </div>
            
            <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-zinc-600">
               <div>© 2024 Webivus Inc. All rights reserved.</div>
               <div className="flex gap-8">
                  <span className="hover:text-white cursor-pointer transition-colors">Terms</span>
                  <span className="hover:text-white cursor-pointer transition-colors">Privacy</span>
                  <span className="hover:text-white cursor-pointer transition-colors">Cookies</span>
               </div>
            </div>
         </footer>
      </div>
   );
};

export default LandingPage;
