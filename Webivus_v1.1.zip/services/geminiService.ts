
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AgentIntent, AgentResponse, ReviewFinding } from "../types";

const MODEL_NAME = 'gemini-3-pro-preview';

// Schema for structured code generation
const codeGenerationSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    intent: {
      type: Type.STRING,
      enum: ["chat", "development", "seo", "bug_fix"],
      description: "The primary intent of the user's request."
    },
    step_by_step_plan: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A specific list of actions you will take. E.g. 'Create src/components/Header.tsx', 'Update tailwind.config.ts'. Only include file manipulations."
    },
    message: {
      type: Type.STRING,
      description: "A conversational response explaining what was done."
    },
    files: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          path: { type: Type.STRING, description: "The file path, e.g., src/components/MyComponent.tsx" },
          code: { type: Type.STRING, description: "The full source code for the file." },
          description: { type: Type.STRING, description: "Brief description of changes." }
        },
        required: ["path", "code"]
      }
    }
  },
  required: ["intent", "message", "files"]
};

// New Schema for structured code review
const codeReviewSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    findings: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          severity: { type: Type.STRING, enum: ["high", "medium", "low", "info", "success"] },
          message: { type: Type.STRING }
        },
        required: ["severity", "message"]
      }
    },
    summary: { type: Type.STRING, description: "Overall summary of the review" }
  },
  required: ["findings", "summary"]
};

export const sendMessageToGemini = async (
  prompt: string,
  currentFiles: Record<string, string>
): Promise<AgentResponse> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    return {
      text: "API Key is missing.",
      intent: AgentIntent.CHAT
    };
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const fileContext = Object.entries(currentFiles)
      .map(([path, content]) => `--- FILE: ${path} ---\n${content}\n`)
      .join("\n");

    const systemPrompt = `
      You are Webivus AI, an expert Full-Stack Engineer.
      CONTEXT:
      You have access to the following project files:
      ${fileContext}
      GOAL: Generate production-ready React/Next.js/Tailwind code based on user request.
      
      INSTRUCTIONS:
      1. Analyze the user request.
      2. If it requires code changes, first list the specific files you will create or modify in the 'step_by_step_plan'.
      3. Then generate the code in the 'files' array.
      4. If it is just a chat question, set intent to 'chat' and leave files empty.
      
      OUTPUT FORMAT: Return strictly JSON matching the schema.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: codeGenerationSchema,
        thinkingConfig: { thinkingBudget: 1024 }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      text: result.message || "I've processed your request.",
      intent: (result.intent as AgentIntent) || AgentIntent.DEVELOPMENT,
      plan: result.step_by_step_plan || [],
      proposedChanges: result.files?.map((f: any) => ({
        file: f.path,
        code: f.code,
        diff: ""
      }))
    };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Error processing request.", intent: AgentIntent.BUG_FIX };
  }
};

export const reviewCodeChanges = async (
  filename: string,
  newCode: string,
  contextFiles: Record<string, string>
): Promise<{ findings: ReviewFinding[], summary: string }> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key missing");

  const ai = new GoogleGenAI({ apiKey });

  try {
    const systemPrompt = `
      You are the Webivus AI Code Reviewer. 
      Analyze the provided code changes for:
      1. Security (XSS, Injection, Sensitive data)
      2. Performance (Re-renders, Memory leaks)
      3. Accessibility (ARIA, semantic HTML)
      4. Best Practices (Clean code, Next.js conventions)
      
      BE CRITICAL BUT HELPFUL.
      If the code is perfect, include a 'success' severity finding.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Review the following changes in ${filename}:\n\n${newCode}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: codeReviewSchema
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Review Error:", error);
    return { findings: [], summary: "Failed to perform code review." };
  }
};
