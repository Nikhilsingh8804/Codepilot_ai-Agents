
import { Octokit } from "@octokit/rest";
import { User } from "../types";

// NOTE: In a production React app, you should NOT expose your personal access token 
// or client secrets on the client side. This should be proxied through a backend.
// This service simulates the interface for demonstration purposes.

let octokitInstance: Octokit | null = null;
let isSimulated = false;

const MOCK_REPOS = [
  { 
    id: 1, 
    name: "nextjs-portfolio", 
    full_name: "webivus-user/nextjs-portfolio", 
    description: "My personal site built with Next.js 14 and Tailwind.", 
    updated_at: "2024-05-10T12:00:00Z", 
    private: false,
    language: "TypeScript",
    stargazers_count: 24,
    default_branch: "main"
  },
  { 
    id: 2, 
    name: "e-commerce-platform", 
    full_name: "webivus-user/e-commerce-platform", 
    description: "feat: implemented stripe checkout webhooks", 
    updated_at: "2024-05-08T09:30:00Z", 
    private: true,
    language: "TypeScript",
    stargazers_count: 5,
    default_branch: "develop"
  },
  { 
    id: 3, 
    name: "webivus-frontend", 
    full_name: "webivus-user/webivus-frontend", 
    description: "fix: resolved hydration errors on dashboard", 
    updated_at: "2024-05-11T14:20:00Z", 
    private: false,
    language: "JavaScript",
    stargazers_count: 156,
    default_branch: "master"
  },
  { 
    id: 4, 
    name: "python-backend-api", 
    full_name: "webivus-user/python-backend-api", 
    description: "FastAPI service for data processing", 
    updated_at: "2024-05-01T10:15:00Z", 
    private: true,
    language: "Python",
    stargazers_count: 2,
    default_branch: "main"
  },
];

export const initializeOctokit = (token: string) => {
  // stricter check: if token is empty, missing, or explicitly 'simulated-token', use simulation
  if (!token || token.trim() === '' || token === 'simulated-token') {
    isSimulated = true;
  } else {
    isSimulated = false;
  }
  
  octokitInstance = new Octokit({
    auth: token,
  });
};

export const validateToken = async (token: string): Promise<User> => {
  const tempOctokit = new Octokit({ auth: token });
  const { data } = await tempOctokit.users.getAuthenticated();
  
  // Initialize the singleton if validation succeeds
  initializeOctokit(token);

  return {
    id: data.id.toString(),
    name: data.name || data.login,
    email: data.email || `${data.login}@users.noreply.github.com`,
    avatarUrl: data.avatar_url,
    provider: 'github',
    githubConnected: true
  };
};

export interface GithubInstallation {
  id: number;
  account: {
    login: string;
    avatar_url: string;
    type: string;
  };
}

// SIMULATED: Get list of accounts where the App is installed
export const getGithubInstallations = async (): Promise<GithubInstallation[]> => {
  await new Promise(resolve => setTimeout(resolve, 600));
  // Return empty array to simulate "Not Installed" state initially, 
  // or return mock data if you want to skip the install step.
  // For this demo, we'll return a mock installation to show the dropdown, 
  // but you can return [] to test the "Install" UI.
  return [
    { id: 123, account: { login: 'webivus-user', avatar_url: 'https://github.com/identicons/webivus.png', type: 'User' } }
  ];
};

export const installGithubApp = async () => {
   // Simulates the popup window flow for installing the GitHub App
   await new Promise(resolve => setTimeout(resolve, 1500));
   return { success: true };
}

export const getUserRepos = async () => {
  // Return mock data immediately if simulated
  if (isSimulated) {
    await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
    return MOCK_REPOS;
  }

  if (!octokitInstance) {
    return MOCK_REPOS;
  }
  
  try {
    const { data } = await octokitInstance.repos.listForAuthenticatedUser({
      sort: 'updated',
      per_page: 20,
      type: 'all'
    });
    return data;
  } catch (error: any) {
    // Gracefully handle 401 Bad Credentials by falling back to simulation
    if (error.status === 401) {
      console.warn("GitHub API Authentication failed (Bad Credentials). Switching to simulated mode.");
      isSimulated = true; 
      return MOCK_REPOS;
    }
    console.warn("GitHub API Error, falling back to mock data:", error);
    return MOCK_REPOS;
  }
};

export const fetchRepoFiles = async (owner: string, repo: string): Promise<Record<string, string>> => {
  if (!octokitInstance || isSimulated) {
     // Return the mock files if simulated so the workspace still works
     return {}; 
  }

  try {
    // 1. Get default branch (usually main or master)
    const { data: repoData } = await octokitInstance.repos.get({ owner, repo });
    const defaultBranch = repoData.default_branch;

    // 2. Get the tree recursively
    // First get the branch ref to find the SHA
    const { data: refData } = await octokitInstance.git.getRef({
        owner, repo, ref: `heads/${defaultBranch}`
    });
    const sha = refData.object.sha;

    const { data: treeData } = await octokitInstance.git.getTree({
        owner, repo, tree_sha: sha, recursive: 'true'
    });

    // 3. Filter for text files we care about to avoid downloading images/binaries or huge paths
    const textExtensions = ['.ts', '.tsx', '.js', '.jsx', '.css', '.json', '.md', '.html', '.txt', '.yml', '.yaml'];
    
    // Safety limit: only fetch up to 50 files for this demo to avoid rate limits and UI freezing
    const filesToFetch = treeData.tree.filter(item => 
        item.type === 'blob' && 
        item.path && 
        textExtensions.some(ext => item.path?.endsWith(ext)) &&
        !item.path.includes('node_modules') &&
        !item.path.includes('.git') &&
        !item.path.includes('dist') &&
        !item.path.includes('build')
    ).slice(0, 50); 

    const files: Record<string, string> = {};

    // 4. Fetch contents in parallel
    // NOTE: GitHub API has rate limits. In a real app, this should be lazy-loaded or proxied.
    await Promise.all(filesToFetch.map(async (file) => {
        if (!file.path || !file.sha) return;
        try {
            const { data } = await octokitInstance!.git.getBlob({
                owner, repo, file_sha: file.sha
            });
            // Content is usually base64 encoded for getBlob
            const content = atob(data.content.replace(/\n/g, ''));
            files[file.path] = content;
        } catch (e) {
            console.error(`Failed to fetch ${file.path}`, e);
        }
    }));

    return files;

  } catch (error) {
      console.error("Error fetching repo files:", error);
      // Fallback: return empty object, Workspace will handle it or show empty state
      return {}; 
  }
};

export const createBranch = async (owner: string, repo: string, branchName: string, sha: string) => {
  if (!octokitInstance || isSimulated) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { status: 201, data: { ref: `refs/heads/${branchName}` } };
  }
  
  try {
    return await octokitInstance.git.createRef({
      owner,
      repo,
      ref: `refs/heads/${branchName}`,
      sha,
    });
  } catch (error: any) {
    if (error.status === 401) {
       console.warn("Authentication failed during createBranch. Switching to simulation.");
       isSimulated = true;
       return { status: 201, data: { ref: `refs/heads/${branchName}` } };
    }
    console.warn("GitHub Create Branch Error (Simulating success):", error);
    return { status: 201, data: { ref: `refs/heads/${branchName}` } };
  }
};

export const createPullRequest = async (owner: string, repo: string, title: string, head: string, base: string) => {
  if (!octokitInstance || isSimulated) {
    await new Promise(resolve => setTimeout(resolve, 1500));
    return { data: { html_url: "https://github.com/webivus-user/demo/pull/1" } };
  }

  try {
    return await octokitInstance.pulls.create({
      owner,
      repo,
      title,
      head,
      base,
    });
  } catch (error: any) {
    if (error.status === 401) {
       console.warn("Authentication failed during createPR. Switching to simulation.");
       isSimulated = true;
       return { data: { html_url: "https://github.com/webivus-user/demo/pull/1" } };
    }
    console.warn("GitHub Create PR Error (Simulating success):", error);
    return { data: { html_url: "https://github.com/webivus-user/demo/pull/1" } };
  }
};
