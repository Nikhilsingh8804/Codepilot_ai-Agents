
import React, { useState } from 'react';
import Login from './components/auth/Login';
import ProjectImport from './components/dashboard/ProjectImport';
import Workspace from './components/workspace/Workspace';
import LandingPage from './components/landing/LandingPage';
import Dashboard from './components/dashboard/Dashboard';
import IndexingScreen from './components/dashboard/IndexingScreen';
import SummaryScreen from './components/dashboard/SummaryScreen';
import { AppView, Project, User } from './types';
import { initializeOctokit } from './services/githubService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);

  const handleGetStarted = () => {
    setCurrentView(AppView.LOGIN);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentView(AppView.DASHBOARD);
  };

  const handleConnectGithub = (token?: string) => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, githubConnected: true });
      // If user provided a token, use it. Otherwise use the simulation token.
      initializeOctokit(token || 'simulated-token');
    }
  };

  const handleProjectSelect = (project: Project) => {
    // If project is already indexed, go to workspace. Else import flow.
    // For demo simplicity, existing projects in list are "ready".
    setCurrentProject(project);
    setCurrentView(AppView.WORKSPACE);
  };

  const handleImportStart = () => {
    setCurrentView(AppView.IMPORT);
  };

  const handleProjectImported = (project: Project) => {
    setCurrentProject(project);
    setCurrentView(AppView.INDEXING);
  };

  const handleIndexingComplete = (indexedProject: Project) => {
    setCurrentProject(indexedProject);
    setProjects(prev => [...prev, indexedProject]);
    // Transition to the new Summary Screen instead of Workspace directly
    setCurrentView(AppView.SUMMARY);
  };

  const handleSummaryContinue = () => {
    setCurrentView(AppView.WORKSPACE);
  }

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentProject(null);
    setCurrentView(AppView.LANDING);
  };

  const handleBackToDashboard = () => {
    setCurrentView(AppView.DASHBOARD);
  }

  return (
    <div className="antialiased text-foreground bg-background min-h-screen">
      {/* Landing Page is visible on LANDING or LOGIN (as background) */}
      {(currentView === AppView.LANDING || currentView === AppView.LOGIN) && (
        <LandingPage 
            onGetStarted={handleGetStarted} 
            user={currentUser} 
            onLogout={handleLogout} 
        />
      )}

      {/* Login acts as a Modal Overlay */}
      {currentView === AppView.LOGIN && (
        <Login 
          onLogin={handleLogin} 
          onClose={() => setCurrentView(AppView.LANDING)} 
        />
      )}

      {currentView === AppView.DASHBOARD && currentUser && (
        <Dashboard 
          user={currentUser}
          onConnectGithub={handleConnectGithub}
          onImportProject={handleImportStart}
          onSelectProject={handleProjectSelect}
          projects={projects}
        />
      )}

      {currentView === AppView.IMPORT && currentUser && (
        <ProjectImport 
          user={currentUser}
          onProjectSelect={handleProjectImported} 
          onBack={handleBackToDashboard}
        />
      )}

      {currentView === AppView.INDEXING && currentProject && (
        <IndexingScreen 
          project={currentProject} 
          onComplete={handleIndexingComplete} 
        />
      )}

      {currentView === AppView.SUMMARY && currentProject && (
        <SummaryScreen 
          project={currentProject}
          onContinue={handleSummaryContinue}
        />
      )}

      {currentView === AppView.WORKSPACE && currentProject && currentUser && (
        <Workspace 
          project={currentProject} 
          user={currentUser}
          onLogout={handleLogout}
          onBack={handleBackToDashboard}
        />
      )}
    </div>
  );
};

export default App;
