
export enum AppView {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  IMPORT = 'IMPORT',
  INDEXING = 'INDEXING',
  SUMMARY = 'SUMMARY',
  WORKSPACE = 'WORKSPACE',
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  provider: 'github' | 'google' | 'email';
  githubConnected?: boolean;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  repoUrl?: string;
  branch: string;
  lastUpdated: string;
  framework: 'Next.js' | 'React' | 'Vue' | 'Other';
  routerType?: string;
  stylingSystem?: string;
  componentCount?: number;
  pageCount?: number;
  apiRouteCount?: number;
  issues?: string[];
  files?: Record<string, string>;
}

export interface AgentStep {
  id: string;
  label: string;
  status: 'pending' | 'active' | 'completed';
  agentName: 'Intent' | 'SEO' | 'Developer' | 'Git' | 'QA' | 'Reviewer' | 'System' | 'Architect' | 'QA Agent';
}

export interface GitAction {
  type: 'branch' | 'commit' | 'push' | 'pr' | 'merge' | 'dependency';
  command: string;
  status: 'pending' | 'success' | 'error';
  data?: any;
}

export interface ReviewFinding {
  severity: 'high' | 'medium' | 'low' | 'info' | 'success';
  message: string;
}

export interface ActionRequest {
  type: 'git_commit' | 'git_push' | 'create_pr' | 'merge_pr' | 'deploy' | 'continue_chat';
  label: string;
  data?: any;
  primary?: boolean;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  intent?: AgentIntent;
  steps?: AgentStep[];
  gitAction?: GitAction;
  reviewFindings?: ReviewFinding[];
  actionRequest?: ActionRequest;
  actions?: ActionRequest[]; // Support for multiple actions
}

export enum AgentIntent {
  CHAT = 'chat',
  DEVELOPMENT = 'development',
  SEO = 'seo',
  BUG_FIX = 'bug_fix',
}

export interface AgentResponse {
  text: string;
  intent: AgentIntent;
  plan?: string[]; // Dynamic steps returned by AI
  proposedChanges?: {
    file: string;
    code: string;
    diff: string;
  }[];
}

export type ImportMethod = 'github' | 'vercel' | 'netlify' | 'upload';